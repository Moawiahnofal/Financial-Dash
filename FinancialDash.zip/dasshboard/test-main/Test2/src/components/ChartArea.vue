<template>
  <section :class="$style.chartArea">
    <div :class="$style.chartContainer">
      <div :class="$style.chartContent">
        <div :class="$style.chartDetails">
          <img :class="$style.chartDetailsChild" loading="lazy" alt="" src="" />
        </div>
        <div :class="$style.frameParent">
          <div :class="$style.vectorWrapper">
            <img
              :class="$style.vectorIcon"
              loading="lazy"
              alt=""
              src="/vector4.svg"
            />
          </div>
          <div :class="$style.chartDataPoints">
            <img
              :class="$style.chartDataPointsChild"
              loading="lazy"
              alt=""
              src="/vector-3.svg"
            />
            <div :class="$style.maxDataPoint" />
          </div>
        </div>
      </div>
      <div :class="$style.financialSummary">
        <div :class="$style.summaryDetails">
          <div :class="$style.financialData">
            <div :class="$style.increaseDetails">
              <div :class="$style.increaseInfo">
                <b :class="$style.emptyLabel">$2,900</b>
                <b :class="$style.increase">
                  <p :class="$style.increase1">+4% increase</p>
                </b>
                <img
                  :class="$style.vectorIcon1"
                  loading="lazy"
                  alt=""
                  src="/vector.svg"
                />
                <div :class="$style.increasePoint" />
                <div :class="$style.financialPeriod">
                  <b :class="$style.jan8">8 Jan - 8 Dec 2023</b>
                  <div :class="$style.financialCategories">
                    <div :class="$style.categoryContainer">
                      <b :class="$style.income">Income</b>
                      <div :class="$style.spendingCategory">
                        <div :class="$style.spendingPoint">
                          <div :class="$style.spendingDataPoint" />
                        </div>
                        <b :class="$style.spending">Spending</b>
                      </div>
                    </div>
                  </div>
                </div>
                <div :class="$style.separator" />
              </div>
              <div :class="$style.chartBarsContainer">
                <div :class="$style.chartBars">
                  <div :class="$style.valueLabel">
                    <b :class="$style.valuePlaceholder">
                      <p :class="$style.p">$400</p>
                      <p :class="$style.p1">$300</p>
                      <p :class="$style.p2">$200</p>
                      <p :class="$style.p3">$100</p>
                      <p :class="$style.p4">$0</p>
                    </b>
                  </div>
                  <div :class="$style.chartBarsInner">
                    <div :class="$style.vectorParent">
                      <img
                        :class="$style.frameChild"
                        alt=""
                        src="/line-1.svg"
                      />
                      <img :class="$style.frameItem" alt="" src="/line-3.svg" />
                    </div>
                  </div>
                  <div :class="$style.chartBarsChild">
                    <div :class="$style.vectorGroup">
                      <img
                        :class="$style.frameInner"
                        alt=""
                        src="/line-4.svg"
                      />
                      <img :class="$style.lineIcon" alt="" src="/line-5.svg" />
                    </div>
                  </div>
                  <div :class="$style.barElement">
                    <img
                      :class="$style.barElementChild"
                      alt=""
                      src="/line-4.svg"
                    />
                  </div>
                  <div :class="$style.barDataPoint">
                    <div :class="$style.dataPointContainer">
                      <img
                        :class="$style.dataPointContainerChild"
                        alt=""
                        src="/line-7.svg"
                      />
                      <div :class="$style.dataPointDetails">
                        <div :class="$style.dataValue">
                          <div :class="$style.valueElements">
                            <img
                              :class="$style.valueElementsChild"
                              loading="lazy"
                              alt=""
                              src="/rectangle-74.svg"
                            />
                            <div :class="$style.valueElementsItem" />
                          </div>
                          <div :class="$style.valueLabel1">
                            <b :class="$style.dataPointValue">$271.00</b>
                            <div :class="$style.valueName">
                              <b :class="$style.income1">Income</b>
                            </div>
                          </div>
                        </div>
                        <div :class="$style.vectorContainer">
                          <img
                            :class="$style.frameChild1"
                            alt=""
                            src="/line-9.svg"
                          />
                          <img
                            :class="$style.frameChild2"
                            alt=""
                            src="/line-8.svg"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div :class="$style.barElement1">
                    <div :class="$style.frameDiv">
                      <img
                        :class="$style.frameChild3"
                        alt=""
                        src="/line-1.svg"
                      />
                      <img
                        :class="$style.frameChild4"
                        alt=""
                        src="/line-11.svg"
                      />
                    </div>
                  </div>
                  <div :class="$style.chartBarsInner1">
                    <div :class="$style.vectorParent1">
                      <img
                        :class="$style.frameChild5"
                        alt=""
                        src="/line-4.svg"
                      />
                      <img
                        :class="$style.frameChild6"
                        alt=""
                        src="/line-13.svg"
                      />
                    </div>
                  </div>
                  <div :class="$style.barDataPoint1">
                    <div :class="$style.dataPointContainer1">
                      <img
                        :class="$style.dataPointContainerItem"
                        alt=""
                        src="/line-14.svg"
                      />
                      <div :class="$style.dataPointDetails1">
                        <div :class="$style.dataPointDetailsChild" />
                        <div :class="$style.dataPointHighlight">
                          <img
                            :class="$style.dataPointHighlightChild"
                            alt=""
                            src="/line-15.svg"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div :class="$style.transactions">
            <div :class="$style.transactionHeader">
              <h1 :class="$style.recentTransactions">Recent Transactions</h1>
            </div>
            <div :class="$style.transactionsList">
              <div :class="$style.transactionContainer">
                <div :class="$style.transactionsContent">
                  <div :class="$style.transactionItem">
                    <div :class="$style.transactionDetails">
                      <div :class="$style.transactionTitle">
                        <div :class="$style.transactionNameContainer">
                          <div :class="$style.transactionName">
                            <div :class="$style.productName">
                              <div :class="$style.productIcon" />
                              <div :class="$style.productNameElements">
                                <img
                                  :class="$style.productNameElementsChild"
                                  alt=""
                                  src="/rectangle-56.svg"
                                />
                                <div :class="$style.productNameBackground" />
                              </div>
                              <img
                                :class="$style.productNameChild"
                                loading="lazy"
                                alt=""
                                src="/rectangle-58.svg"
                              />
                            </div>
                          </div>
                          <b :class="$style.buyPs5">Buy PS5</b>
                        </div>
                      </div>
                      <div :class="$style.transactionProgress">
                        <div :class="$style.progressContainer">
                          <div :class="$style.progressBar">
                            <div :class="$style.progressPoint" />
                            <img
                              :class="$style.progressBarChild"
                              alt=""
                              src=""
                            />
                            <img
                              :class="$style.progressBarItem"
                              alt=""
                              src=""
                            />
                            <img
                              :class="$style.progressBarInner"
                              alt=""
                              src=""
                            />
                            <img
                              :class="$style.progressBarChild1"
                              alt=""
                              src=""
                            />
                          </div>
                          <div :class="$style.vectorParent2">
                            <img
                              :class="$style.ellipseIcon"
                              alt=""
                              src="/ellipse-61.svg"
                            />
                            <img
                              :class="$style.rectangleIcon"
                              loading="lazy"
                              alt=""
                              src="/rectangle-59.svg"
                            />
                          </div>
                        </div>
                        <b :class="$style.dribbblePro">Dribbble Pro</b>
                      </div>
                    </div>
                  </div>
                  <div :class="$style.card">
                    <div :class="$style.redDotParent">
                      <div :class="$style.redDot" />
                      <div :class="$style.rectangleDiv" />
                      <img
                        :class="$style.frameChild7"
                        alt=""
                        src="/ellipse-67.svg"
                      />
                      <img
                        :class="$style.frameChild8"
                        alt=""
                        src="/ellipse-69.svg"
                      />
                      <img
                        :class="$style.frameChild9"
                        alt=""
                        src="/ellipse-68.svg"
                      />
                      <img
                        :class="$style.frameChild10"
                        alt=""
                        src="/ellipse-66.svg"
                      />
                    </div>
                    <div :class="$style.location">
                      <b :class="$style.coffeePore">Coffee Pore</b>
                    </div>
                  </div>
                </div>
              </div>
              <div :class="$style.transactionsListInner">
                <div :class="$style.june2024Parent">
                  <b :class="$style.june2024">24 June 2024</b>
                  <div :class="$style.june2024Wrapper">
                    <b :class="$style.june20241">19 June 2024</b>
                  </div>
                  <b :class="$style.june20242">11June 2024</b>
                </div>
              </div>
              <div :class="$style.transactions1">
                <div :class="$style.statusRowWrapper">
                  <div :class="$style.statusRow">
                    <div :class="$style.statusCell">
                      <div :class="$style.vectorParent3">
                        <img
                          :class="$style.frameChild11"
                          loading="lazy"
                          alt=""
                          src="/ellipse-12.svg"
                        />
                        <b :class="$style.completed">Completed</b>
                      </div>
                    </div>
                    <div :class="$style.vectorParent4">
                      <img
                        :class="$style.frameChild12"
                        loading="lazy"
                        alt=""
                        src="/ellipse-12.svg"
                      />
                      <b :class="$style.completed1">Completed</b>
                    </div>
                  </div>
                </div>
                <div :class="$style.vectorParent5">
                  <img
                    :class="$style.frameChild13"
                    loading="lazy"
                    alt=""
                    src="/ellipse-16.svg"
                  />
                  <b :class="$style.cancel">Cancel</b>
                </div>
              </div>
              <div :class="$style.transactionDetails1">
                <div :class="$style.transactionLabelWrapper">
                  <div :class="$style.transactionLabel">
                    <b :class="$style.buyPs51">Buy PS5</b>
                    <b :class="$style.dribbblePro1">Dribbble Pro</b>
                  </div>
                </div>
                <b :class="$style.schoolFees">School fees</b>
              </div>
              <div :class="$style.spacer">
                <div :class="$style.padding">
                  <div :class="$style.verticalSpaceParent">
                    <div :class="$style.verticalSpace">
                      <b :class="$style.b">
                        <p :class="$style.p5">-$302.00%</p>
                      </b>
                    </div>
                    <b :class="$style.b1">
                      <p :class="$style.p6">-$112.00%</p>
                    </b>
                  </div>
                  <b :class="$style.b2">
                    <p :class="$style.p7">+$80.00%</p>
                  </b>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div :class="$style.spacer1">
        <div :class="$style.padding1">
          <div :class="$style.verticalSpace1">
            <div :class="$style.profileDetailsParent">
              <div :class="$style.profileDetails">
                <div :class="$style.maritalStatus">
                  <div :class="$style.maritalLabelParent">
                    <b :class="$style.maritalLabel">48%</b>
                    <div :class="$style.frameGroup">
                      <div :class="$style.lineWrapper">
                        <div :class="$style.lineDiv" />
                      </div>
                      <div :class="$style.checkmarkContainer">
                        <Ellipse />
                        <div :class="$style.checkmarkContainerChild" />
                        <div :class="$style.checkmarkContainerItem" />
                        <div :class="$style.checkmarkContainerInner" />
                      </div>
                      <div :class="$style.frameChild14" />
                    </div>
                  </div>
                  <div :class="$style.lineParent">
                    <div :class="$style.frameChild15" />
                    <div :class="$style.educationLevel">
                      <b :class="$style.schoolLabel">77%</b>
                    </div>
                  </div>
                </div>
                <div :class="$style.statusIconWrapper">
                  <div :class="$style.statusIcon">
                    <b :class="$style.married">Married</b>
                    <div :class="$style.educationIcon">
                      <div :class="$style.statusCheckmarkWrapper">
                        <div :class="$style.statusCheckmark" />
                      </div>
                      <b :class="$style.school">School</b>
                    </div>
                  </div>
                </div>
              </div>
              <div :class="$style.imageWrapperWrapper">
                <div :class="$style.imageWrapper">
                  <b :class="$style.imageLabel">88%</b>
                  <div :class="$style.placeholderImage" />
                  <img
                    :class="$style.imageWrapperChild"
                    loading="lazy"
                    alt=""
                    src="/line-61.svg"
                  />
                </div>
              </div>
            </div>
          </div>
          <div :class="$style.banner">
            <b :class="$style.letsSaveMoney">Let’s save money now!</b>
            <img :class="$style.bannerChild" alt="" src="/line-22.svg" />
            <img
              :class="$style.backgroundGradientIcon"
              alt=""
              src="/vector-9.svg"
            />
            <img
              :class="$style.backgroundGradientIcon1"
              alt=""
              src="/vector-9.svg"
            />
            <div :class="$style.rectangleParent">
              <div :class="$style.frameChild16" />
              <div :class="$style.circleButtonParent">
                <div :class="$style.circleButton" />
                <img :class="$style.frameChild17" alt="" src="" />
                <img
                  :class="$style.frameChild18"
                  loading="lazy"
                  alt=""
                  src=""
                />
              </div>
              <div :class="$style.progressBar1">
                <img
                  :class="$style.progressBarChild2"
                  alt=""
                  src="/line-18.svg"
                />
                <div :class="$style.progressSteps" />
                <div :class="$style.progressSteps1" />
                <img
                  :class="$style.progressBarChild3"
                  alt=""
                  src="/rectangle-15.svg"
                />
                <img
                  :class="$style.progressBarChild4"
                  alt=""
                  src="/rectangle-16.svg"
                />
              </div>
              <div :class="$style.frameChild19" />
              <div :class="$style.goalIconWrapper">
                <div :class="$style.goalIcon">
                  <img
                    :class="$style.goalIconChild"
                    alt=""
                    src="/ellipse-39.svg"
                  />
                  <div :class="$style.iconBackground">
                    <div :class="$style.targetCircle" />
                    <div :class="$style.completionIcon">
                      <img
                        :class="$style.completionIconChild"
                        alt=""
                        src="/vector-25.svg"
                      />
                      <div :class="$style.vectorParent6">
                        <img
                          :class="$style.frameChild20"
                          alt=""
                          src="/vector-26.svg"
                        />
                        <img :class="$style.frameChild21" alt="" src="" />
                        <img
                          :class="$style.frameChild22"
                          alt=""
                          src="/vector-28.svg"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div :class="$style.goalVisual">
                <div :class="$style.goalBars" />
                <div :class="$style.goalBars1" />
                <div :class="$style.progressMarker" />
                <img
                  :class="$style.goalVisualChild"
                  alt=""
                  src="/ellipse-28.svg"
                />
                <div :class="$style.container">
                  <div :class="$style.circle" />
                  <div :class="$style.circleContainer">
                    <img
                      :class="$style.circleContainerChild"
                      alt=""
                      src="/ellipse-30.svg"
                    />
                    <img
                      :class="$style.vectorIcon2"
                      alt=""
                      src="/vector6.svg"
                    />
                  </div>
                </div>
              </div>
              <div :class="$style.divider">
                <img
                  :class="$style.dividerChild"
                  alt=""
                  src="/rectangle-35.svg"
                />
                <div :class="$style.dividerItem" />
                <div :class="$style.dividerInner" />
                <img
                  :class="$style.dividerChild1"
                  alt=""
                  src="/vector-22.svg"
                />
              </div>
              <div :class="$style.lineGroup">
                <div :class="$style.frameChild23" />
                <div :class="$style.frameChild24" />
                <div :class="$style.frameChild25" />
                <div :class="$style.lineContainer">
                  <div :class="$style.frameChild26" />
                  <div :class="$style.frameChild27" />
                  <div :class="$style.frameChild28" />
                  <img :class="$style.frameChild29" alt="" src="" />
                </div>
                <div :class="$style.shapes">
                  <img
                    :class="$style.shapesChild"
                    alt=""
                    src="/rectangle-36.svg"
                  />
                  <img :class="$style.shapesItem" alt="" src="/vector-23.svg" />
                  <img
                    :class="$style.shapesInner"
                    alt=""
                    src="/vector-24.svg"
                  />
                </div>
              </div>
              <div :class="$style.shapeContainer">
                <img
                  :class="$style.shapeContainerChild"
                  alt=""
                  src="/rectangle-39.svg"
                />
                <img
                  :class="$style.shapeContainerItem"
                  alt=""
                  src="/rectangle-37.svg"
                />
                <div :class="$style.shapeContainerInner" />
                <div :class="$style.circleContainer1">
                  <img
                    :class="$style.vectorIcon3"
                    loading="lazy"
                    alt=""
                    src="/vector7.svg"
                  />
                  <img
                    :class="$style.circleContainerItem"
                    alt=""
                    src="/ellipse-36.svg"
                  />
                </div>
                <div :class="$style.rectangleGroup">
                  <div :class="$style.frameChild30" />
                  <div :class="$style.circleContainer2">
                    <img
                      :class="$style.vectorIcon4"
                      alt=""
                      src="/vector8.svg"
                    />
                    <img
                      :class="$style.circleContainerInner"
                      alt=""
                      src="/ellipse-37.svg"
                    />
                  </div>
                </div>
              </div>
              <div :class="$style.makeSharedSavingsMoreFunAParent">
                <b :class="$style.makeSharedSavings"
                  >Make shared savings more fun and faster</b
                >
                <div :class="$style.button">
                  <div :class="$style.buttonChild" />
                  <b :class="$style.saveNow">Save Now</b>
                </div>
              </div>
              <div :class="$style.vectorParent7">
                <img :class="$style.frameChild31" alt="" src="/line-31.svg" />
                <img :class="$style.frameChild32" alt="" src="/vector-8.svg" />
                <img
                  :class="$style.frameChild33"
                  loading="lazy"
                  alt=""
                  src="/line-33.svg"
                />
                <img
                  :class="$style.frameChild34"
                  alt=""
                  src="/rectangle-28.svg"
                />
              </div>
              <div :class="$style.container1">
                <div :class="$style.container2">
                  <div :class="$style.container3">
                    <div :class="$style.container4">
                      <img
                        :class="$style.containerChild"
                        alt=""
                        src="/vector-17.svg"
                      />
                      <div :class="$style.container5">
                        <img
                          :class="$style.containerItem"
                          alt=""
                          src="/vector-18.svg"
                        />
                        <div :class="$style.container6">
                          <img
                            :class="$style.containerInner"
                            alt=""
                            src="/vector-19.svg"
                          />
                          <div :class="$style.vectorParent8">
                            <img
                              :class="$style.frameChild35"
                              alt=""
                              src="/vector-20.svg"
                            />
                            <img
                              :class="$style.frameChild36"
                              alt=""
                              src="/vector-21.svg"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div :class="$style.container7">
                  <div :class="$style.container8">
                    <div :class="$style.container9">
                      <div :class="$style.container10">
                        <div :class="$style.container11">
                          <img :class="$style.containerChild1" alt="" src="" />
                          <div :class="$style.containerChild2" />
                          <div :class="$style.circle1" />
                          <img
                            :class="$style.containerChild3"
                            alt=""
                            src="/ellipse-38.svg"
                          />
                        </div>
                      </div>
                      <div :class="$style.container12">
                        <div :class="$style.container13">
                          <div :class="$style.containerChild4" />
                          <div :class="$style.container14">
                            <img
                              :class="$style.containerChild5"
                              alt=""
                              src="/rectangle-10.svg"
                            />
                            <div :class="$style.containerChild6" />
                            <img
                              :class="$style.containerChild7"
                              loading="lazy"
                              alt=""
                              src="/line-23.svg"
                            />
                            <div :class="$style.circleContainer3">
                              <div :class="$style.circle2" />
                              <div :class="$style.circleContainer4">
                                <img
                                  :class="$style.circleContainerChild1"
                                  alt=""
                                  src="/ellipse-22.svg"
                                />
                                <img
                                  :class="$style.vectorIcon5"
                                  loading="lazy"
                                  alt=""
                                  src="/vector-191.svg"
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div :class="$style.vectorParent9">
                        <img
                          :class="$style.frameChild37"
                          alt=""
                          src="/rectangle-5.svg"
                        />
                        <img :class="$style.frameChild38" alt="" src="" />
                        <img :class="$style.frameChild39" alt="" src="" />
                        <img
                          :class="$style.frameChild40"
                          alt=""
                          src="/line-21.svg"
                        />
                      </div>
                    </div>
                  </div>
                  <div :class="$style.container15">
                    <div :class="$style.container16">
                      <div :class="$style.container17">
                        <div :class="$style.container18">
                          <div :class="$style.container19">
                            <img
                              :class="$style.containerChild8"
                              alt=""
                              src="/rectangle-29.svg"
                            />
                            <img
                              :class="$style.containerChild9"
                              alt=""
                              src="/vector-13.svg"
                            />
                            <img
                              :class="$style.containerChild10"
                              alt=""
                              src="/vector-15.svg"
                            />
                            <img
                              :class="$style.containerChild11"
                              alt=""
                              src="/vector-16.svg"
                            />
                          </div>
                        </div>
                        <div :class="$style.containerChild12" />
                      </div>
                      <div :class="$style.container20">
                        <div :class="$style.container21">
                          <img
                            :class="$style.containerChild13"
                            alt=""
                            src="/vector-6.svg"
                          />
                          <img
                            :class="$style.containerChild14"
                            alt=""
                            src="/vector-7.svg"
                          />
                        </div>
                        <div :class="$style.container22">
                          <div :class="$style.containerChild15" />
                        </div>
                      </div>
                    </div>
                    <div :class="$style.container23">
                      <div :class="$style.container24">
                        <div :class="$style.lineParent1">
                          <div :class="$style.frameChild41" />
                          <img
                            :class="$style.frameIcon"
                            loading="lazy"
                            alt=""
                            src="/frame-22@2x.png"
                          />
                          <img
                            :class="$style.frameChild42"
                            loading="lazy"
                            alt=""
                            src="/frame-22@2x.png"
                          />
                          <img
                            :class="$style.frameChild43"
                            loading="lazy"
                            alt=""
                            src="/frame-24@2x.png"
                          />
                          <div :class="$style.circleParent">
                            <div :class="$style.circle3" />
                            <img
                              :class="$style.frameChild44"
                              alt=""
                              src="/ellipse-25.svg"
                            />
                            <img
                              :class="$style.vectorIcon6"
                              loading="lazy"
                              alt=""
                              src="/vector6.svg"
                            />
                            <div :class="$style.frameChild45" />
                            <div :class="$style.frameChild46" />
                            <div :class="$style.frameChild47" />
                            <div :class="$style.frameChild48" />
                            <div :class="$style.frameChild49" />
                            <img
                              :class="$style.vectorIcon7"
                              alt=""
                              src="/vector11.svg"
                            />
                            <img
                              :class="$style.vectorIcon8"
                              alt=""
                              src="/vector12.svg"
                            />
                            <img
                              :class="$style.frameChild50"
                              alt=""
                              src="/ellipse-76.svg"
                            />
                            <img
                              :class="$style.frameChild51"
                              alt=""
                              src="/ellipse-77.svg"
                            />
                            <div :class="$style.ellipseDiv" />
                            <img
                              :class="$style.frameChild52"
                              alt=""
                              src="/ellipse-79.svg"
                            />
                            <img
                              :class="$style.vectorIcon9"
                              alt=""
                              src="/vector13.svg"
                            />
                            <img
                              :class="$style.designIcon"
                              loading="lazy"
                              alt=""
                              src="/frame-25@2x.png"
                            />
                          </div>
                          <img
                            :class="$style.frameChild53"
                            alt=""
                            src="/rectangle-17.svg"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div :class="$style.vectorParent10">
                <img
                  :class="$style.frameChild54"
                  alt=""
                  src="/rectangle-21.svg"
                />
                <img
                  :class="$style.frameChild55"
                  loading="lazy"
                  alt=""
                  src="/vector-30.svg"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
<script lang="ts">
  import { defineComponent } from "vue";
  import Ellipse from "./Ellipse.vue";

  export default defineComponent({
    name: "ChartArea",
    components: { Ellipse },
  });
</script>
<style module>
  .chartDetailsChild {
    width: 0px;
    height: 25px;
    position: relative;
  }
  .chartDetails {
    width: 0px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-8xl) 0px 0px;
    box-sizing: border-box;
  }
  .vectorIcon {
    height: 47px;
    width: 36px;
    position: relative;
  }
  .vectorWrapper {
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-end;
    padding: 0px var(--padding-5xs) 0px var(--padding-3xs);
  }
  .chartDataPointsChild {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
  }
  .maxDataPoint {
    position: absolute;
    top: 18px;
    left: 21px;
    border-radius: 50%;
    background-color: var(--color-gainsboro-200);
    border: 0px solid var(--color-gray-400);
    box-sizing: border-box;
    width: 20px;
    height: 18px;
    z-index: 1;
  }
  .chartDataPoints {
    align-self: stretch;
    height: 53px;
    position: relative;
  }
  .frameParent {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    justify-content: flex-start;
    gap: var(--gap-31xl);
  }
  .chartContent {
    width: 139px;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px var(--padding-59xl) 0px 0px;
    box-sizing: border-box;
    gap: var(--gap-6xs);
  }
  .emptyLabel {
    position: absolute;
    top: 5px;
    left: 0px;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    width: 145px;
    height: 40px;
    white-space: nowrap;
  }
  .increase1 {
    margin-block-start: 0;
    margin-block-end: 30px;
    white-space: pre-wrap;
  }
  .increase {
    position: absolute;
    top: 4px;
    left: 183px;
    font-size: var(--font-size-lg);
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    color: var(--color-limegreen);
    width: 208px;
    height: 33px;
  }
  .vectorIcon1 {
    position: absolute;
    top: 22px;
    left: 209px;
    width: 11px;
    height: 9px;
    z-index: 1;
  }
  .increasePoint {
    position: absolute;
    top: 72px;
    left: 575px;
    border-radius: 50%;
    background-color: var(--color-powderblue-100);
    width: 14px;
    height: 14px;
  }
  .jan8 {
    width: 162px;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
  }
  .income {
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    min-width: 61px;
  }
  .spendingDataPoint {
    width: 14px;
    height: 14px;
    position: relative;
    border-radius: 50%;
    background-color: var(--color-darkorchid);
  }
  .spendingPoint {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-smi) 0px 0px;
  }
  .spending {
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    min-width: 83px;
  }
  .spendingCategory {
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-5xs);
  }
  .categoryContainer {
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-2xl);
  }
  .financialCategories {
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px 0px 0px var(--padding-11xs);
  }
  .financialPeriod {
    position: absolute;
    top: 0px;
    left: 596px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-xl);
    font-size: var(--font-size-base);
    color: var(--color-gray-400);
  }
  .separator {
    position: absolute;
    top: 25px;
    left: 900px;
    filter: blur(4px);
    border-right: 1px solid var(--color-gray-600);
    box-sizing: border-box;
    width: 1px;
    height: 92px;
    z-index: 5;
  }
  .increaseInfo {
    align-self: stretch;
    height: 116px;
    position: relative;
  }
  .p {
    margin-block-start: 0;
    margin-block-end: 30px;
  }
  .p1 {
    margin-block-start: 0;
    margin-block-end: 30px;
  }
  .p2 {
    margin-block-start: 0;
    margin-block-end: 30px;
  }
  .p3 {
    margin-block-start: 0;
    margin-block-end: 30px;
  }
  .p4 {
    margin: 0;
  }
  .valuePlaceholder {
    align-self: stretch;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
  }
  .valueLabel {
    width: 103px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px var(--padding-4xs) 0px 0px;
    box-sizing: border-box;
  }
  .frameChild {
    height: 257px;
    width: 0px;
    position: relative;
    object-fit: contain;
  }
  .frameItem {
    height: 194px;
    width: 0px;
    position: relative;
    object-fit: contain;
  }
  .vectorParent {
    width: 55px;
    flex: 1;
    display: flex;
    flex-direction: row;
    align-items: flex-end;
    justify-content: space-between;
    padding: 0px var(--padding-xl) 0px 0px;
    box-sizing: border-box;
    gap: var(--gap-xl);
  }
  .chartBarsInner {
    height: 307px;
    width: 95px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-31xl) 0px 0px;
    box-sizing: border-box;
  }
  .frameInner {
    height: 243px;
    width: 0px;
    position: relative;
    object-fit: contain;
  }
  .lineIcon {
    height: 109px;
    width: 0px;
    position: relative;
    object-fit: contain;
  }
  .vectorGroup {
    width: 63px;
    flex: 1;
    display: flex;
    flex-direction: row;
    align-items: flex-end;
    justify-content: space-between;
    padding: 0px var(--padding-xl) 0px 0px;
    box-sizing: border-box;
    gap: var(--gap-xl);
  }
  .chartBarsChild {
    height: 307px;
    width: 94px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-45xl) 0px 0px;
    box-sizing: border-box;
  }
  .barElementChild {
    width: 0px;
    flex: 1;
    position: relative;
    max-height: 100%;
    object-fit: contain;
  }
  .barElement {
    height: 307px;
    width: 0px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-45xl) 0px 0px;
    box-sizing: border-box;
  }
  .dataPointContainerChild {
    height: 102px;
    width: 0px;
    position: relative;
    object-fit: contain;
  }
  .valueElementsChild {
    position: absolute;
    top: 0px;
    left: 0px;
    border-radius: var(--br-9xs);
    width: 100%;
    height: 100%;
  }
  .valueElementsItem {
    position: absolute;
    top: 16px;
    left: 5px;
    border-radius: 50%;
    background-color: var(--color-black);
    border: 0px solid var(--color-gainsboro-300);
    box-sizing: border-box;
    width: 9px;
    height: 8px;
    z-index: 1;
  }
  .valueElements {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
  }
  .dataPointValue {
    align-self: stretch;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 33px;
    flex-shrink: 0;
    white-space: nowrap;
    z-index: 1;
  }
  .income1 {
    flex: 1;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    flex-shrink: 0;
    z-index: 2;
  }
  .valueName {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px var(--padding-3xs) 0px var(--padding-smi);
    margin-top: -25px;
    font-size: var(--font-size-8xs);
    color: var(--color-gainsboro-400);
  }
  .valueLabel1 {
    position: absolute;
    top: 0px;
    left: 16px;
    width: 47px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
  }
  .dataValue {
    align-self: stretch;
    height: 39px;
    position: relative;
  }
  .frameChild1 {
    height: 129px;
    width: 0px;
    position: relative;
    object-fit: contain;
  }
  .frameChild2 {
    height: 102px;
    width: 0px;
    position: relative;
    object-fit: contain;
  }
  .vectorContainer {
    width: 31.5px;
    flex: 1;
    display: flex;
    flex-direction: row;
    align-items: flex-end;
    justify-content: space-between;
    gap: var(--gap-xl);
  }
  .dataPointDetails {
    align-self: stretch;
    width: 73px;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    justify-content: flex-start;
    gap: var(--gap-xs);
  }
  .dataPointContainer {
    width: 137px;
    flex: 1;
    display: flex;
    flex-direction: row;
    align-items: flex-end;
    justify-content: space-between;
    padding: 0px var(--padding-xl) 0px 0px;
    box-sizing: border-box;
    gap: var(--gap-xl);
  }
  .barDataPoint {
    height: 307px;
    width: 175px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-108xl) 0px 0px;
    box-sizing: border-box;
    font-size: var(--font-size-3xs);
    color: var(--color-white);
  }
  .frameChild3 {
    height: 257px;
    width: 0px;
    position: relative;
    object-fit: contain;
  }
  .frameChild4 {
    height: 156px;
    width: 0px;
    position: relative;
    object-fit: contain;
  }
  .frameDiv {
    width: 43px;
    flex: 1;
    display: flex;
    flex-direction: row;
    align-items: flex-end;
    justify-content: space-between;
    gap: var(--gap-xl);
  }
  .barElement1 {
    height: 311px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-35xl) var(--padding-21xl) 0px 0px;
    box-sizing: border-box;
  }
  .frameChild5 {
    height: 243px;
    width: 0px;
    position: relative;
    object-fit: contain;
  }
  .frameChild6 {
    height: 214px;
    width: 0px;
    position: relative;
    object-fit: contain;
  }
  .vectorParent1 {
    width: 35px;
    flex: 1;
    display: flex;
    flex-direction: row;
    align-items: flex-end;
    justify-content: space-between;
    gap: var(--gap-xl);
  }
  .chartBarsInner1 {
    height: 307px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-45xl) var(--padding-21xl) 0px 0px;
    box-sizing: border-box;
  }
  .dataPointContainerItem {
    height: 206px;
    width: 0px;
    position: relative;
    object-fit: contain;
  }
  .dataPointDetailsChild {
    width: 14px;
    height: 14px;
    position: relative;
    border-radius: 50%;
    background-color: var(--color-powderblue-100);
  }
  .dataPointHighlightChild {
    height: 143px;
    width: 0px;
    position: relative;
    object-fit: contain;
  }
  .dataPointHighlight {
    flex: 1;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-end;
    padding: 0px var(--padding-8xs) 0px var(--padding-4xs);
  }
  .dataPointDetails1 {
    align-self: stretch;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    justify-content: flex-start;
    gap: var(--gap-127xl);
  }
  .dataPointContainer1 {
    flex: 1;
    display: flex;
    flex-direction: row;
    align-items: flex-end;
    justify-content: flex-start;
    gap: var(--gap-6xl);
  }
  .barDataPoint1 {
    height: 311px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-5xs) 0px 0px;
    box-sizing: border-box;
  }
  .chartBars {
    flex: 1;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: space-between;
    max-width: 100%;
    gap: var(--gap-xl);
  }
  .chartBarsContainer {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px 0px 0px var(--padding-11xs);
    box-sizing: border-box;
    max-width: 100%;
    margin-top: -3px;
    font-size: var(--font-size-base);
    color: var(--color-gray-300);
  }
  .increaseDetails {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    max-width: 100%;
  }
  .financialData {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px 0px 0px var(--padding-5xl);
    box-sizing: border-box;
    max-width: 100%;
  }
  .recentTransactions {
    margin: 0;
    flex: 1;
    position: relative;
    font-size: inherit;
    letter-spacing: -0.01em;
    line-height: 40px;
    font-weight: 700;
    font-family: inherit;
    display: inline-block;
    max-width: 100%;
  }
  .transactionHeader {
    width: 411px;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px var(--padding-4xl);
    box-sizing: border-box;
    max-width: 100%;
  }
  .productIcon {
    position: absolute;
    top: 0px;
    left: 0px;
    border-radius: 50%;
    background-color: var(--color-goldenrod);
    width: 41px;
    height: 38px;
  }
  .productNameElementsChild {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 1;
  }
  .productNameBackground {
    position: absolute;
    top: 3px;
    left: 11px;
    border-radius: var(--br-3xs);
    background-color: var(--color-gray-800);
    width: 3px;
    height: 18px;
    z-index: 2;
  }
  .productNameElements {
    position: absolute;
    top: 7px;
    left: 13px;
    width: 15px;
    height: 22px;
  }
  .productNameChild {
    position: absolute;
    top: 29px;
    left: 7px;
    width: 30px;
    height: 10px;
    z-index: 2;
  }
  .productName {
    height: 39px;
    width: 41px;
    position: relative;
  }
  .transactionName {
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
  }
  .buyPs5 {
    flex: 1;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
  }
  .transactionNameContainer {
    flex: 1;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-mini);
  }
  .transactionTitle {
    width: 165px;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px var(--padding-12xs);
    box-sizing: border-box;
  }
  .progressPoint {
    position: absolute;
    top: 0px;
    left: 0px;
    border-radius: 50%;
    background-color: var(--color-darkviolet-100);
    border: 0px solid var(--color-whitesmoke-100);
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    z-index: 1;
  }
  .progressBarChild {
    position: absolute;
    top: 4.1px;
    left: 3.7px;
    width: 8.7px;
    height: 10.7px;
    object-fit: contain;
    z-index: 2;
  }
  .progressBarItem {
    position: absolute;
    top: 4.3px;
    left: 4.5px;
    width: 7.4px;
    height: 10.7px;
    object-fit: contain;
    z-index: 3;
  }
  .progressBarInner {
    position: absolute;
    top: 8.2px;
    left: 1.8px;
    width: 13.5px;
    height: 0.5px;
    object-fit: contain;
    z-index: 4;
  }
  .progressBarChild1 {
    position: absolute;
    top: 2.5px;
    left: 8.2px;
    width: 0.8px;
    height: 14.4px;
    object-fit: contain;
    z-index: 5;
  }
  .progressBar {
    width: 16px;
    height: 19px;
    position: relative;
  }
  .ellipseIcon {
    position: absolute;
    height: 100%;
    width: 100%;
    top: 0px;
    right: 0px;
    bottom: 0px;
    left: 0px;
    max-width: 100%;
    overflow: hidden;
    max-height: 100%;
  }
  .rectangleIcon {
    position: absolute;
    top: 27px;
    left: 8px;
    width: 27px;
    height: 13px;
    z-index: 2;
  }
  .vectorParent2 {
    width: 100%;
    height: 100%;
    position: absolute;
    margin: 0 !important;
    top: 0px;
    right: 0px;
    bottom: 0px;
    left: 0px;
  }
  .progressContainer {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-5xs) var(--padding-smi) var(--padding-sm);
    position: relative;
  }
  .dribbblePro {
    flex: 1;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
  }
  .transactionProgress {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-mini);
    color: var(--color-black);
  }
  .transactionDetails {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-smi);
  }
  .transactionItem {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px 0px 0px var(--padding-11xs);
  }
  .redDot {
    position: absolute;
    top: 0px;
    left: 0px;
    border-radius: 50%;
    background-color: var(--color-powderblue-200);
    width: 100%;
    height: 100%;
  }
  .rectangleDiv {
    position: absolute;
    top: 11px;
    left: 18px;
    background-color: var(--color-khaki-200);
    width: 12px;
    height: 4px;
    z-index: 1;
  }
  .frameChild7 {
    position: absolute;
    top: 24px;
    left: 13px;
    width: 27px;
    height: 11px;
    z-index: 1;
  }
  .frameChild8 {
    position: absolute;
    top: 37px;
    left: 11px;
    width: 27px;
    height: 5px;
    z-index: 1;
  }
  .frameChild9 {
    position: absolute;
    top: 32px;
    left: 7px;
    width: 27px;
    height: 7px;
    z-index: 2;
  }
  .frameChild10 {
    position: absolute;
    top: 15px;
    left: 17px;
    width: 13px;
    height: 12px;
    z-index: 2;
  }
  .redDotParent {
    height: 42px;
    width: 47px;
    position: relative;
  }
  .coffeePore {
    align-self: stretch;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
  }
  .location {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-6xs) 0px 0px;
  }
  .card {
    width: 171px;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-xs);
  }
  .transactionsContent {
    align-self: stretch;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-2xs);
  }
  .transactionContainer {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-7xs) var(--padding-8xl) 0px 0px;
    box-sizing: border-box;
    min-width: 146px;
  }
  .june2024 {
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    min-width: 107px;
  }
  .june20241 {
    flex: 1;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
  }
  .june2024Wrapper {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px 0px var(--padding-8xs);
    color: var(--color-black);
  }
  .june20242 {
    width: 112px;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
  }
  .june2024Parent {
    width: 139px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-xs);
  }
  .transactionsListInner {
    width: 190px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-7xs) 0px 0px;
    box-sizing: border-box;
  }
  .frameChild11 {
    position: absolute;
    top: 6.5px;
    left: 0px;
    width: 103.5px;
    height: 28px;
  }
  .completed {
    position: absolute;
    top: 0px;
    left: 10px;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    width: 107px;
    height: 39px;
    z-index: 1;
  }
  .vectorParent3 {
    height: 39px;
    flex: 1;
    position: relative;
  }
  .statusCell {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px 0px 0px var(--padding-11xs);
  }
  .frameChild12 {
    position: absolute;
    top: 6.5px;
    left: 0px;
    width: 103.5px;
    height: 28px;
  }
  .completed1 {
    position: absolute;
    top: 0px;
    left: 10px;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    width: 107px;
    height: 39px;
    z-index: 1;
  }
  .vectorParent4 {
    align-self: stretch;
    height: 39px;
    position: relative;
  }
  .statusRow {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-7xs);
  }
  .statusRowWrapper {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px var(--padding-2xs) 0px var(--padding-12xs);
  }
  .frameChild13 {
    position: absolute;
    top: 8.5px;
    left: 0px;
    width: 103.5px;
    height: 28px;
  }
  .cancel {
    position: absolute;
    top: 0px;
    left: 24px;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    width: 107px;
    height: 39px;
    z-index: 1;
  }
  .vectorParent5 {
    align-self: stretch;
    height: 39px;
    position: relative;
    color: var(--color-red);
  }
  .transactions1 {
    width: 162px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px var(--padding-12xl) 0px 0px;
    box-sizing: border-box;
    gap: var(--gap-3xl);
    color: var(--color-green);
  }
  .buyPs51 {
    width: 107px;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
  }
  .dribbblePro1 {
    align-self: stretch;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    color: var(--color-black);
  }
  .transactionLabel {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-7xs);
  }
  .transactionLabelWrapper {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px 0px 0px var(--padding-12xs);
  }
  .schoolFees {
    align-self: stretch;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
  }
  .transactionDetails1 {
    width: 140px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-4xl);
  }
  .p5 {
    margin-block-start: 0;
    margin-block-end: 30px;
  }
  .b {
    flex: 1;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 33px;
  }
  .verticalSpace {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px 0px 0px var(--padding-12xs);
  }
  .p6 {
    margin-block-start: 0;
    margin-block-end: 30px;
  }
  .b1 {
    width: 84px;
    height: 33px;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    flex-shrink: 0;
  }
  .verticalSpaceParent {
    align-self: stretch;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-3xs);
  }
  .p7 {
    margin-block-start: 0;
    margin-block-end: 30px;
  }
  .b2 {
    width: 98px;
    height: 33px;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    color: var(--color-limegreen);
    flex-shrink: 0;
  }
  .padding {
    align-self: stretch;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-9xl);
  }
  .spacer {
    width: 110px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-11xs) 0px 0px;
    box-sizing: border-box;
    color: var(--color-salmon);
  }
  .transactionsList {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-sm);
    font-size: var(--font-size-base);
    color: var(--color-gray-400);
  }
  .transactions {
    width: 903px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px var(--padding-xl) 0px 0px;
    box-sizing: border-box;
    gap: var(--gap-smi);
    max-width: 100%;
    font-size: var(--font-size-17xl);
    color: var(--color-black);
  }
  .summaryDetails {
    align-self: stretch;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-13xl);
    max-width: 100%;
  }
  .financialSummary {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-xl) 0px 0px;
    box-sizing: border-box;
    min-width: 603px;
    max-width: 100%;
  }
  .maritalLabel {
    height: 34.4px;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    flex-shrink: 0;
    min-width: 62px;
  }
  .lineDiv {
    height: 1px;
    width: 18px;
    position: relative;
    filter: blur(4px);
    border-top: 1px solid var(--color-gray-1300);
    box-sizing: border-box;
    z-index: 6;
  }
  .lineWrapper {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
  }
  .checkmarkContainerChild {
    position: absolute;
    top: 188px;
    left: 35px;
    background-color: var(--color-white);
    width: 4px;
    height: 4px;
    z-index: 7;
  }
  .checkmarkContainerItem {
    position: absolute;
    top: 227px;
    left: 124px;
    background-color: var(--color-white);
    width: 4px;
    height: 4px;
    z-index: 5;
  }
  .checkmarkContainerInner {
    position: absolute;
    top: 38px;
    left: 202px;
    background-color: var(--color-white);
    width: 4px;
    height: 4px;
    z-index: 6;
  }
  .checkmarkContainer {
    width: 100%;
    height: 100%;
    position: absolute;
    margin: 0 !important;
    top: 0px;
    right: 0px;
    bottom: 0px;
    left: 0px;
  }
  .frameChild14 {
    width: 9px;
    height: 1px;
    position: relative;
    filter: blur(4px);
    border-top: 1px solid var(--color-gray-600);
    box-sizing: border-box;
    z-index: 6;
  }
  .frameGroup {
    width: 246px;
    margin: 0 !important;
    position: absolute;
    top: -227px;
    right: -159px;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    justify-content: flex-end;
    padding: var(--padding-171xl) var(--padding-105xl) var(--padding-2xs)
      var(--padding-lg);
    box-sizing: border-box;
    gap: var(--gap-20xl);
  }
  .maritalLabelParent {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-3xl-7) 0px 0px;
    position: relative;
  }
  .frameChild15 {
    align-self: stretch;
    width: 1px;
    position: relative;
    filter: blur(4px);
    border-right: 1px solid var(--color-gray-600);
    box-sizing: border-box;
    z-index: 5;
  }
  .schoolLabel {
    align-self: stretch;
    height: 34.4px;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    flex-shrink: 0;
  }
  .educationLevel {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-7xl-7) 0px 0px;
  }
  .lineParent {
    align-self: stretch;
    flex: 1;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-6xs);
  }
  .maritalStatus {
    align-self: stretch;
    flex: 1;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-8xl);
  }
  .married {
    flex: 1;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    z-index: 1;
  }
  .statusCheckmark {
    width: 14px;
    height: 14px;
    position: relative;
    border-radius: 50%;
    background-color: var(--color-khaki-300);
  }
  .statusCheckmarkWrapper {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-2xs-8) 0px 0px;
  }
  .school {
    flex: 1;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    z-index: 1;
  }
  .educationIcon {
    flex: 1;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-8xs);
  }
  .statusIcon {
    flex: 1;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-2xs);
  }
  .statusIconWrapper {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px var(--padding-7xs) 0px var(--padding-8xs);
    margin-top: -13.3px;
    font-size: var(--font-size-xs);
    color: var(--color-gray-400);
  }
  .profileDetails {
    align-self: stretch;
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
  }
  .imageLabel {
    position: relative;
    letter-spacing: -0.01em;
    line-height: 43px;
    display: inline-block;
    min-width: 56px;
  }
  .placeholderImage {
    height: 14px;
    width: 14px;
    position: absolute;
    margin: 0 !important;
    bottom: -10px;
    left: -11px;
    border-radius: 50%;
    background-color: var(--color-darkviolet-100);
    z-index: 1;
  }
  .imageWrapperChild {
    height: 233px;
    width: 62.5px;
    position: absolute;
    margin: 0 !important;
    top: -205px;
    left: -6px;
    object-fit: contain;
    z-index: 5;
  }
  .imageWrapper {
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    position: relative;
  }
  .imageWrapperWrapper {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-xl) 0px 0px;
  }
  .profileDetailsParent {
    align-self: stretch;
    flex: 1;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-2xl);
  }
  .verticalSpace1 {
    align-self: stretch;
    height: 85.2px;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-end;
    padding: 0px var(--padding-2xs) 0px 0px;
    box-sizing: border-box;
  }
  .letsSaveMoney {
    width: 174px;
    position: absolute;
    margin: 0 !important;
    right: -3px;
    bottom: 116px;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    z-index: 1;
  }
  .bannerChild {
    height: 12.8px;
    width: 3.2px;
    position: absolute;
    margin: 0 !important;
    top: 123.1px;
    left: 35.4px;
    border-radius: var(--br-3xs);
    object-fit: contain;
    z-index: 5;
  }
  .backgroundGradientIcon {
    height: 0.1px;
    width: 1px;
    position: absolute;
    margin: 0 !important;
    top: 100px;
    right: 103px;
    z-index: 4;
  }
  .backgroundGradientIcon1 {
    height: 0.1px;
    width: 1px;
    position: absolute;
    margin: 0 !important;
    top: 98px;
    right: 103px;
    z-index: 4;
  }
  .frameChild16 {
    position: absolute;
    top: 0px;
    left: 0px;
    background-color: var(--color-gray-500);
    border: 1px solid var(--color-black);
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    display: none;
  }
  .circleButton {
    position: absolute;
    top: 0px;
    left: 0px;
    border-radius: 50%;
    background-color: var(--color-gainsboro-500);
    width: 100%;
    height: 100%;
    z-index: 1;
  }
  .frameChild17 {
    position: absolute;
    top: 5.6px;
    left: 3.8px;
    width: 6.9px;
    height: 9.4px;
    object-fit: contain;
    z-index: 2;
  }
  .frameChild18 {
    position: absolute;
    top: 6.1px;
    left: 4.3px;
    width: 5.5px;
    height: 10.5px;
    object-fit: contain;
    z-index: 3;
  }
  .circleButtonParent {
    position: absolute;
    top: 28px;
    left: 186px;
    width: 17px;
    height: 22px;
  }
  .progressBarChild2 {
    position: absolute;
    top: 0px;
    left: 1px;
    width: 3px;
    height: 28px;
    object-fit: contain;
    z-index: 1;
  }
  .progressSteps {
    position: absolute;
    top: 27px;
    left: 11px;
    background-color: var(--color-pink-200);
    width: 7px;
    height: 16px;
    z-index: 3;
  }
  .progressSteps1 {
    position: absolute;
    top: 27px;
    left: 0px;
    background-color: var(--color-pink-200);
    width: 8px;
    height: 16px;
    z-index: 3;
  }
  .progressBarChild3 {
    position: absolute;
    top: 41px;
    left: 0px;
    width: 13px;
    height: 10px;
    z-index: 4;
  }
  .progressBarChild4 {
    position: absolute;
    top: 42px;
    left: 10px;
    width: 13px;
    height: 10px;
    z-index: 5;
  }
  .progressBar1 {
    position: absolute;
    top: 151px;
    left: 36px;
    width: 23px;
    height: 52px;
  }
  .frameChild19 {
    position: absolute;
    top: 146px;
    left: 85px;
    border-top: 0.1px solid var(--color-black);
    box-sizing: border-box;
    width: 5.1px;
    height: 0.1px;
    z-index: 2;
  }
  .goalIconChild {
    position: absolute;
    height: 100%;
    width: 100%;
    top: 0px;
    right: 0px;
    bottom: 0px;
    left: 0px;
    max-width: 100%;
    overflow: hidden;
    max-height: 100%;
    object-fit: contain;
    z-index: 1;
  }
  .targetCircle {
    position: absolute;
    top: 0px;
    left: 0px;
    border-radius: 50%;
    background-color: var(--color-gray-500);
    width: 1px;
    height: 0px;
    z-index: 2;
  }
  .completionIconChild {
    position: absolute;
    top: 1px;
    left: 0px;
    width: 0px;
    height: 1px;
    z-index: 3;
  }
  .frameChild20 {
    position: absolute;
    top: 0px;
    left: 1px;
    width: 1px;
    height: 1px;
    z-index: 4;
  }
  .frameChild21 {
    position: absolute;
    top: 1px;
    left: 3px;
    width: 0px;
    height: 0px;
    display: none;
  }
  .frameChild22 {
    position: absolute;
    top: 1px;
    left: 0px;
    width: 1px;
    height: 0px;
    z-index: 5;
  }
  .vectorParent6 {
    position: absolute;
    top: 0px;
    left: -1px;
    width: 3px;
    height: 1px;
    z-index: 2;
  }
  .completionIcon {
    position: absolute;
    top: -1px;
    left: 1px;
    width: 100%;
    height: 100%;
  }
  .iconBackground {
    position: absolute;
    top: 5px;
    left: 1px;
    width: 1px;
    height: 1px;
  }
  .goalIcon {
    height: 100%;
    width: 100%;
    position: absolute;
    margin: 0 !important;
    top: 0px;
    right: 0px;
    bottom: 0px;
    left: 0px;
  }
  .goalIconWrapper {
    position: absolute;
    top: 100px;
    left: 191px;
    width: 8px;
    height: 8px;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
  }
  .goalBars {
    position: absolute;
    top: 11px;
    left: 3.8px;
    border-radius: var(--br-3xs);
    background-color: var(--color-pink-100);
    width: 12px;
    height: 4px;
    z-index: 3;
  }
  .goalBars1 {
    position: absolute;
    top: 7px;
    left: 4.8px;
    border-radius: var(--br-3xs);
    background-color: var(--color-pink-100);
    width: 12px;
    height: 4px;
    z-index: 4;
  }
  .progressMarker {
    position: absolute;
    top: 5px;
    left: 0.8px;
    background-color: var(--color-pink-400);
    width: 3px;
    height: 3px;
    z-index: 3;
  }
  .goalVisualChild {
    position: absolute;
    top: 1px;
    left: 0px;
    width: 5.4px;
    height: 4px;
    z-index: 4;
  }
  .circle {
    position: absolute;
    top: 0px;
    left: 0px;
    border-radius: 50%;
    background-color: var(--color-khaki-100);
    width: 100%;
    height: 100%;
    z-index: 6;
  }
  .circleContainerChild {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 7;
  }
  .vectorIcon2 {
    position: absolute;
    top: 1px;
    left: 6px;
    width: 13.8px;
    height: 15.6px;
    object-fit: contain;
    z-index: 8;
  }
  .circleContainer {
    position: absolute;
    top: 2px;
    left: 1px;
    width: 25px;
    height: 19px;
  }
  .container {
    position: absolute;
    top: 0px;
    left: 11.8px;
    width: 26px;
    height: 23px;
  }
  .goalVisual {
    position: absolute;
    top: 86px;
    left: 92.2px;
    width: 37.8px;
    height: 23px;
  }
  .dividerChild {
    position: absolute;
    top: 0px;
    left: 0px;
    border-radius: var(--br-3xs);
    width: 100%;
    height: 100%;
    z-index: 2;
  }
  .dividerItem {
    position: absolute;
    top: 14px;
    left: 9px;
    border-top: 0.1px solid var(--color-black);
    box-sizing: border-box;
    width: 3.1px;
    height: 0.1px;
    z-index: 3;
  }
  .dividerInner {
    position: absolute;
    top: 17px;
    left: 9px;
    border-top: 0.1px solid var(--color-black);
    box-sizing: border-box;
    width: 3.1px;
    height: 0.1px;
    z-index: 3;
  }
  .dividerChild1 {
    position: absolute;
    top: 2.2px;
    left: 1.3px;
    width: 2.8px;
    height: 5.3px;
    z-index: 3;
  }
  .divider {
    position: absolute;
    top: 112px;
    left: 183px;
    width: 19px;
    height: 27px;
  }
  .frameChild23 {
    height: 25.1px;
    width: 0.1px;
    position: absolute;
    margin: 0 !important;
    bottom: 7.4px;
    left: 2px;
    border-right: 0.1px solid var(--color-black);
    box-sizing: border-box;
    z-index: 4;
  }
  .frameChild24 {
    height: 0.1px;
    width: 4.1px;
    position: absolute;
    margin: 0 !important;
    top: 14.5px;
    left: 6px;
    border-top: 0.1px solid var(--color-black);
    box-sizing: border-box;
    z-index: 4;
  }
  .frameChild25 {
    height: 0.1px;
    width: 3.1px;
    position: absolute;
    margin: 0 !important;
    top: 21px;
    right: 2.9px;
    border-top: 0.1px solid var(--color-black);
    box-sizing: border-box;
    z-index: 4;
  }
  .frameChild26 {
    height: 0.1px;
    width: 2.1px;
    position: absolute;
    margin: 0 !important;
    right: -0.1px;
    bottom: 14.4px;
    border-top: 0.1px solid var(--color-black);
    box-sizing: border-box;
    z-index: 4;
  }
  .frameChild27 {
    height: 0.1px;
    width: 4.1px;
    position: absolute;
    margin: 0 !important;
    bottom: 14.9px;
    left: 0px;
    border-top: 0.1px solid var(--color-black);
    box-sizing: border-box;
    z-index: 4;
  }
  .frameChild28 {
    height: 0.1px;
    width: 3.1px;
    position: absolute;
    margin: 0 !important;
    right: 0.9px;
    bottom: 14.4px;
    border-top: 0.1px solid var(--color-black);
    box-sizing: border-box;
    z-index: 5;
  }
  .frameChild29 {
    height: 100%;
    width: 4.4px;
    position: absolute;
    margin: 0 !important;
    top: 0px;
    right: 2.4px;
    bottom: 0px;
    max-height: 100%;
    object-fit: contain;
    z-index: 6;
  }
  .lineContainer {
    height: 30px;
    width: 11px;
    margin: 0 !important;
    position: absolute;
    top: 2.5px;
    right: 2px;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
  }
  .shapesChild {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 19px;
    height: 45px;
    z-index: 3;
  }
  .shapesItem {
    position: absolute;
    top: 41px;
    left: 16px;
    width: 4px;
    height: 0px;
    z-index: 4;
  }
  .shapesInner {
    position: absolute;
    top: 39.3px;
    left: 0.7px;
    width: 4.7px;
    height: 0.7px;
    z-index: 4;
  }
  .shapes {
    height: 100%;
    width: 100%;
    position: absolute;
    margin: 0 !important;
    top: 0px;
    right: -1px;
    bottom: 0px;
  }
  .lineGroup {
    position: absolute;
    top: 136px;
    left: 183px;
    width: 19px;
    height: 45px;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
  }
  .shapeContainerChild {
    position: absolute;
    top: 17px;
    left: 31px;
    width: 4px;
    height: 3px;
    z-index: 1;
  }
  .shapeContainerItem {
    position: absolute;
    top: 19px;
    left: 8px;
    border-radius: var(--br-6xs);
    width: 22px;
    height: 18.5px;
    z-index: 1;
  }
  .shapeContainerInner {
    position: absolute;
    top: 18.85px;
    left: 3px;
    border-radius: var(--br-9xs);
    background-color: var(--color-pink-100);
    width: 5.7px;
    height: 8px;
    transform: rotate(-30deg);
    transform-origin: 0 0;
    z-index: 2;
  }
  .vectorIcon3 {
    position: absolute;
    top: 1.7px;
    left: 2.5px;
    width: 7px;
    height: 8.3px;
    object-fit: contain;
    z-index: 5;
  }
  .circleContainerItem {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    object-fit: contain;
    z-index: 7;
  }
  .circleContainer1 {
    position: absolute;
    top: 9.8px;
    left: 7.1px;
    width: 11.8px;
    height: 11.4px;
  }
  .frameChild30 {
    position: absolute;
    top: 7px;
    left: 0px;
    background-color: var(--color-seagreen);
    border: 1px solid var(--color-darkseagreen);
    box-sizing: border-box;
    width: 14px;
    height: 26px;
    transform: rotate(-30deg);
    transform-origin: 0 0;
  }
  .vectorIcon4 {
    position: absolute;
    top: 1px;
    left: 2px;
    width: 5.3px;
    height: 6.3px;
    object-fit: contain;
    z-index: 6;
  }
  .circleContainerInner {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    object-fit: contain;
    z-index: 8;
  }
  .circleContainer2 {
    position: absolute;
    top: 5px;
    left: 4px;
    width: 9.1px;
    height: 8.7px;
  }
  .rectangleGroup {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 25.1px;
    height: 29.5px;
  }
  .shapeContainer {
    position: absolute;
    top: 92px;
    left: 161px;
    width: 35px;
    height: 37.5px;
  }
  .makeSharedSavings {
    position: absolute;
    top: 0px;
    left: 0px;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    width: 175px;
    height: 39px;
    z-index: 2;
  }
  .buttonChild {
    position: absolute;
    top: 7px;
    left: 0px;
    background-color: var(--color-mediumorchid);
    width: 84px;
    height: 28px;
    z-index: 3;
  }
  .saveNow {
    position: absolute;
    top: 0px;
    left: 12px;
    letter-spacing: -0.01em;
    line-height: 27px;
    display: inline-block;
    width: 64px;
    height: 27px;
    min-width: 64px;
    z-index: 4;
  }
  .button {
    position: absolute;
    top: 28px;
    left: 31px;
    width: 84px;
    height: 35px;
    font-size: var(--font-size-xs);
    color: var(--color-gray-500);
  }
  .makeSharedSavingsMoreFunAParent {
    position: absolute;
    top: 283px;
    left: 29px;
    width: 175px;
    height: 63px;
  }
  .frameChild31 {
    position: absolute;
    top: 0px;
    left: 4.6px;
    width: 2.8px;
    height: 40.8px;
    object-fit: contain;
    z-index: 1;
  }
  .frameChild32 {
    position: absolute;
    top: 2px;
    left: 2px;
    width: 3px;
    height: 3px;
    z-index: 2;
  }
  .frameChild33 {
    position: absolute;
    top: 0px;
    left: 10.3px;
    width: 2px;
    height: 40.8px;
    object-fit: contain;
    z-index: 4;
  }
  .frameChild34 {
    position: absolute;
    top: 39px;
    left: 0px;
    width: 15px;
    height: 4.3px;
    z-index: 5;
  }
  .vectorParent7 {
    position: absolute;
    top: 109px;
    left: 84px;
    width: 15px;
    height: 43.3px;
  }
  .containerChild {
    position: absolute;
    top: 0px;
    left: 1.4px;
    width: 0.7px;
    height: 0.7px;
    z-index: 1;
  }
  .containerItem {
    position: absolute;
    top: 0px;
    left: 0.8px;
    width: 0.6px;
    height: 0.8px;
    z-index: 2;
  }
  .containerInner {
    position: absolute;
    top: 0px;
    left: 0.8px;
    width: 0.6px;
    height: 0.9px;
    z-index: 1;
  }
  .frameChild35 {
    position: absolute;
    top: 0px;
    left: 0.4px;
    width: 0.6px;
    height: 0.7px;
    z-index: 1;
  }
  .frameChild36 {
    position: absolute;
    top: 1px;
    left: 0px;
    width: 0.3px;
    height: 0.7px;
    z-index: 1;
  }
  .vectorParent8 {
    position: absolute;
    top: 0.7px;
    left: -0.4px;
    width: 1px;
    height: 1.7px;
  }
  .container6 {
    position: absolute;
    top: 0.5px;
    left: -0.8px;
    width: 100%;
    height: 100%;
  }
  .container5 {
    position: absolute;
    top: 0.2px;
    left: 0px;
    width: 1.4px;
    height: 1.4px;
  }
  .container4 {
    margin-left: -0.8px;
    height: 1.6px;
    width: 2.1px;
    position: relative;
    flex-shrink: 0;
  }
  .container3 {
    height: 1px;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px 0px 0px;
    box-sizing: border-box;
  }
  .container2 {
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-end;
    padding: 0px var(--padding-mid);
  }
  .containerChild1 {
    position: absolute;
    top: 4px;
    left: 5px;
    width: 1px;
    height: 5px;
    z-index: 1;
  }
  .containerChild2 {
    position: absolute;
    top: 6px;
    left: 2px;
    border-radius: var(--br-12xs);
    background-color: var(--color-pink-100);
    width: 5px;
    height: 10px;
    z-index: 4;
  }
  .circle1 {
    position: absolute;
    top: 0px;
    left: 8px;
    border-radius: 50%;
    background-color: var(--color-gray-700);
    width: 0px;
    height: 1px;
    z-index: 1;
  }
  .containerChild3 {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 8.3px;
    height: 7px;
    z-index: 5;
  }
  .container11 {
    height: 16px;
    width: 8.3px;
    position: relative;
  }
  .container10 {
    width: 25.9px;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-end;
    padding: 0px var(--padding-5xs) 0px var(--padding-4xs);
    box-sizing: border-box;
  }
  .containerChild4 {
    position: absolute;
    top: 20px;
    left: 21.9px;
    border-right: 1px solid var(--color-chocolate);
    box-sizing: border-box;
    width: 1px;
    height: 1px;
    z-index: 4;
  }
  .containerChild5 {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 3;
  }
  .containerChild6 {
    position: absolute;
    top: 17.71px;
    left: 10.67px;
    background-color: var(--color-pink-200);
    width: 8.8px;
    height: 3.4px;
    transform: rotate(-38.7deg);
    transform-origin: 0 0;
    z-index: 4;
  }
  .containerChild7 {
    position: absolute;
    top: 5.3px;
    left: 18.6px;
    border-radius: var(--br-3xs);
    width: 5.7px;
    height: 13.5px;
    object-fit: contain;
    z-index: 4;
  }
  .circle2 {
    position: absolute;
    top: 0px;
    left: 0px;
    border-radius: 50%;
    background-color: var(--color-khaki-100);
    width: 100%;
    height: 100%;
    z-index: 6;
  }
  .circleContainerChild1 {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 7;
  }
  .vectorIcon5 {
    position: absolute;
    top: 2px;
    left: 4.3px;
    width: 3px;
    height: 7px;
    z-index: 8;
  }
  .circleContainer4 {
    position: absolute;
    top: 1px;
    left: 0.7px;
    width: 11px;
    height: 11px;
  }
  .circleContainer3 {
    position: absolute;
    top: 2px;
    left: 5.9px;
    width: 12px;
    height: 13px;
  }
  .container14 {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
  }
  .container13 {
    height: 29px;
    width: 24px;
    position: relative;
  }
  .container12 {
    width: 25.9px;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-end;
    padding: 0px var(--padding-12xs) 0px 0px;
    box-sizing: border-box;
  }
  .frameChild37 {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 2;
  }
  .frameChild38 {
    position: absolute;
    top: 16.2px;
    left: 10.7px;
    width: 2.5px;
    height: 1.3px;
    object-fit: contain;
    z-index: 3;
  }
  .frameChild39 {
    position: absolute;
    top: 20.1px;
    left: 11.3px;
    width: 2.5px;
    height: 1.3px;
    object-fit: contain;
    z-index: 3;
  }
  .frameChild40 {
    position: absolute;
    top: 0.7px;
    left: -0.3px;
    width: 7px;
    height: 24.5px;
    object-fit: contain;
    z-index: 3;
  }
  .vectorParent9 {
    width: 24px;
    height: 29px;
    position: relative;
  }
  .container9 {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    justify-content: flex-start;
  }
  .container8 {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-2xs-5) 0px 0px;
  }
  .containerChild8 {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 2;
  }
  .containerChild9 {
    position: absolute;
    top: 2.5px;
    left: 7.6px;
    width: 2.8px;
    height: 2.8px;
    z-index: 3;
  }
  .containerChild10 {
    position: absolute;
    top: 5px;
    left: 7.5px;
    width: 4.5px;
    height: 3.5px;
    z-index: 4;
  }
  .containerChild11 {
    position: absolute;
    top: 11px;
    left: 6.3px;
    width: 3.3px;
    height: 1.3px;
    z-index: 3;
  }
  .container19 {
    width: 12px;
    height: 15.5px;
    position: relative;
  }
  .container18 {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-end;
    padding: 0px 0px var(--padding-11xs);
  }
  .containerChild12 {
    height: 4px;
    flex: 1;
    position: relative;
    border-radius: var(--br-xl);
    background-color: var(--color-gray-100);
    border: 1px solid var(--color-gainsboro-100);
    box-sizing: border-box;
    z-index: 2;
  }
  .container17 {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-end;
    justify-content: flex-start;
    gap: var(--gap-11xs);
  }
  .containerChild13 {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 3px;
    height: 1px;
    z-index: 2;
  }
  .containerChild14 {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 3;
  }
  .container21 {
    height: 4px;
    width: 3.5px;
    position: relative;
  }
  .containerChild15 {
    align-self: stretch;
    height: 4px;
    position: relative;
    border-radius: var(--br-xl);
    background-color: var(--color-gray-100);
    border: 1px solid var(--color-gainsboro-100);
    box-sizing: border-box;
    z-index: 1;
  }
  .container22 {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-11xs) 0px 0px;
  }
  .container20 {
    width: 69px;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-8xs-5);
  }
  .container16 {
    align-self: stretch;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    justify-content: flex-start;
    padding: 0px var(--padding-sm) 0px 0px;
  }
  .frameChild41 {
    height: 0.1px;
    width: 7.1px;
    position: absolute;
    margin: 0 !important;
    top: 28px;
    left: 0px;
    border-top: 0.1px solid var(--color-black);
    box-sizing: border-box;
    z-index: 3;
  }
  .frameIcon {
    height: 7px;
    width: 50px;
    position: absolute;
    margin: 0 !important;
    right: 10px;
    bottom: 15px;
    object-fit: contain;
    z-index: 1;
  }
  .frameChild42 {
    height: 7px;
    width: 50px;
    position: absolute;
    margin: 0 !important;
    right: 10px;
    bottom: 7px;
    object-fit: contain;
    z-index: 1;
  }
  .frameChild43 {
    height: 8px;
    width: 50px;
    position: absolute;
    margin: 0 !important;
    right: 10px;
    bottom: 23px;
    object-fit: contain;
    z-index: 14;
  }
  .circle3 {
    position: absolute;
    top: 0px;
    left: 22px;
    border-radius: 50%;
    background-color: var(--color-khaki-100);
    width: 26px;
    height: 23px;
    z-index: 2;
  }
  .frameChild44 {
    position: absolute;
    top: 2px;
    left: 23px;
    width: 25px;
    height: 19px;
    z-index: 3;
  }
  .vectorIcon6 {
    position: absolute;
    top: 3px;
    left: 29px;
    width: 13.8px;
    height: 15.6px;
    object-fit: contain;
    z-index: 4;
  }
  .frameChild45 {
    position: absolute;
    top: 32px;
    left: 18px;
    background-color: var(--color-pink-100);
    border: 1px solid var(--color-black);
    box-sizing: border-box;
    width: 39px;
    height: 7px;
    z-index: 1;
  }
  .frameChild46 {
    position: absolute;
    top: 38px;
    left: 19px;
    background-color: var(--color-pink-100);
    width: 41px;
    height: 6px;
    z-index: 2;
  }
  .frameChild47 {
    position: absolute;
    top: 44px;
    left: 19px;
    background-color: var(--color-pink-100);
    width: 31px;
    height: 7px;
    z-index: 3;
  }
  .frameChild48 {
    position: absolute;
    top: 32.01px;
    left: 55.74px;
    background-color: var(--color-seagreen);
    border: 1px solid var(--color-darkseagreen);
    box-sizing: border-box;
    width: 18.4px;
    height: 31.9px;
    transform: rotate(26.5deg);
    transform-origin: 0 0;
    z-index: 4;
  }
  .frameChild49 {
    position: absolute;
    top: 32.22px;
    left: 4.1px;
    background-color: var(--color-seagreen);
    border: 1px solid var(--color-darkseagreen);
    box-sizing: border-box;
    width: 18.4px;
    height: 31.9px;
    transform: rotate(-26.5deg);
    transform-origin: 0 0;
    z-index: 6;
  }
  .vectorIcon7 {
    position: absolute;
    top: 37.5px;
    left: 17.2px;
    width: 9.5px;
    height: 9.7px;
    object-fit: contain;
    z-index: 7;
  }
  .vectorIcon8 {
    position: absolute;
    top: 31.1px;
    left: 12.2px;
    width: 7.3px;
    height: 7.4px;
    object-fit: contain;
    z-index: 8;
  }
  .frameChild50 {
    position: absolute;
    top: 35.5px;
    left: 13.7px;
    width: 16px;
    height: 13.4px;
    object-fit: contain;
    z-index: 9;
  }
  .frameChild51 {
    position: absolute;
    top: 29.9px;
    left: 9.5px;
    width: 12.3px;
    height: 10.2px;
    object-fit: contain;
    z-index: 10;
  }
  .ellipseDiv {
    position: absolute;
    top: 40px;
    left: 0px;
    border-radius: 50%;
    background-color: var(--color-khaki-100);
    width: 31px;
    height: 30px;
    z-index: 11;
  }
  .frameChild52 {
    position: absolute;
    top: 43px;
    left: 1px;
    width: 29px;
    height: 25px;
    z-index: 12;
  }
  .vectorIcon9 {
    position: absolute;
    top: 42.8px;
    left: 5.4px;
    width: 20px;
    height: 23.6px;
    object-fit: contain;
    z-index: 13;
  }
  .designIcon {
    position: absolute;
    top: 53px;
    left: 33px;
    width: 40px;
    height: 7px;
    object-fit: contain;
    z-index: 15;
  }
  .circleParent {
    height: 70px;
    width: 75px;
    position: absolute;
    margin: 0 !important;
    top: -1px;
    left: 2px;
  }
  .frameChild53 {
    height: 90px;
    width: 85px;
    position: relative;
    border-radius: var(--br-xl);
    z-index: 16;
  }
  .lineParent1 {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    position: relative;
  }
  .container24 {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
  }
  .container23 {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px 0px 0px var(--padding-9xs);
  }
  .container15 {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-12xs);
  }
  .container7 {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-10xl);
  }
  .container1 {
    position: absolute;
    top: 87.7px;
    left: 30.1px;
    width: 143.9px;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    justify-content: flex-start;
    gap: var(--gap-8xs-8);
  }
  .frameChild54 {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 17;
  }
  .frameChild55 {
    position: absolute;
    top: 1.7px;
    left: 5.6px;
    width: 1.3px;
    height: 38.1px;
    z-index: 18;
  }
  .vectorParent10 {
    position: absolute;
    top: 109px;
    left: 84.5px;
    width: 12.5px;
    height: 41px;
  }
  .rectangleParent {
    height: 410px;
    flex: 1;
    position: relative;
    background-color: var(--color-gray-500);
    border: 1px solid var(--color-black);
    box-sizing: border-box;
    font-size: var(--font-size-5xs);
    color: var(--color-gainsboro-600);
  }
  .banner {
    width: 208px;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    position: relative;
    font-size: var(--font-size-sm);
    color: var(--color-white);
  }
  .padding1 {
    align-self: stretch;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    justify-content: flex-start;
    gap: var(--gap-93xl-8);
  }
  .spacer1 {
    width: 241px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-63xl) 0px 0px;
    box-sizing: border-box;
    font-size: var(--font-size-6xl);
    color: var(--color-black);
  }
  .chartContainer {
    flex: 1;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-11xs);
    max-width: 100%;
  }
  .chartArea {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px 0px 0px var(--padding-16xl);
    box-sizing: border-box;
    max-width: 100%;
    text-align: left;
    font-size: var(--font-size-21xl);
    color: var(--color-gray-200);
    font-family: var(--font-inter);
  }

  @media screen and (max-width: 1025px) {
    .emptyLabel {
      font-size: var(--font-size-13xl);
      line-height: 32px;
    }

    .chartBars {
      flex-wrap: wrap;
    }

    .recentTransactions {
      font-size: var(--font-size-10xl);
      line-height: 32px;
    }

    .transactionsList {
      flex-wrap: wrap;
    }

    .financialSummary {
      min-width: 100%;
    }
  }
  @media screen and (max-width: 750px) {
    .spacer1 {
      padding-top: var(--padding-34xl);
      box-sizing: border-box;
    }
  }
  @media screen and (max-width: 450px) {
    .emptyLabel {
      font-size: var(--font-size-5xl);
      line-height: 24px;
    }

    .recentTransactions {
      font-size: var(--font-size-3xl);
      line-height: 24px;
    }

    .summaryDetails {
      gap: var(--gap-base);
    }

    .maritalLabel {
      font-size: var(--font-size-xl);
      line-height: 32px;
    }

    .schoolLabel {
      font-size: var(--font-size-xl);
      line-height: 32px;
    }

    .imageLabel {
      font-size: var(--font-size-xl);
      line-height: 32px;
    }
  }
</style>
