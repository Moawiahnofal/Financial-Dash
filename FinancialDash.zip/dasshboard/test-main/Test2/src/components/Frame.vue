<template>
  <div :class="$style.chartAreaWrapper">
    <div :class="$style.chartArea">
      <div :class="$style.frameParent">
        <div :class="$style.vectorWrapper">
          <img
            :class="$style.vectorIcon"
            loading="lazy"
            alt=""
            src="/vector3.svg"
          />
        </div>
        <div :class="$style.lineWrapper">
          <div :class="$style.frameChild" />
        </div>
        <div :class="$style.vectorParent">
          <img :class="$style.frameItem" alt="" src="/rectangle-1.svg" />
          <div :class="$style.incomeHeaderParent">
            <div :class="$style.incomeHeader">
              <b :class="$style.income">Income</b>
            </div>
            <div :class="$style.incomeHeader1">
              <b :class="$style.b">
                <span>$</span>
                <span :class="$style.span">5,830</span>
              </b>
            </div>
            <div :class="$style.incomeDetails">
              <b :class="$style.incomeValue">
                <p :class="$style.p">+10%</p>
              </b>
              <div :class="$style.ellipseParent">
                <div :class="$style.frameInner" />
                <img
                  :class="$style.vectorIcon1"
                  loading="lazy"
                  alt=""
                  src="/vector1.svg"
                />
              </div>
            </div>
          </div>
          <div :class="$style.spendingHeaderWrapper">
            <div :class="$style.spendingHeader">
              <img
                :class="$style.spendingTitlesIcon"
                loading="lazy"
                alt=""
                src="/frame-14@2x.png"
              />
              <img
                :class="$style.spendingTitlesIcon1"
                loading="lazy"
                alt=""
                src="/frame-15@2x.png"
              />
              <div :class="$style.spendingBarParent">
                <div :class="$style.spendingBar" />
                <img :class="$style.vectorIcon2" alt="" src="/vector14.svg" />
              </div>
              <div :class="$style.ellipseGroup">
                <div :class="$style.ellipseDiv" />
                <div :class="$style.vectorGroup">
                  <img
                    :class="$style.ellipseIcon"
                    alt=""
                    src="/ellipse-71.svg"
                  />
                  <img :class="$style.vectorIcon3" alt="" src="/vector15.svg" />
                </div>
              </div>
              <img
                :class="$style.spendingTitlesIcon2"
                loading="lazy"
                alt=""
                src="/frame-15@2x.png"
              />
              <img
                :class="$style.spendingHeaderChild"
                alt=""
                src="/frame-17@2x.png"
              />
              <img :class="$style.spendingHeaderItem" alt="" src="" />
              <img
                :class="$style.spendingHeaderInner"
                alt=""
                src="/polygon-1.svg"
              />
              <div :class="$style.rectangleDiv" />
            </div>
          </div>
        </div>
        <div :class="$style.balanceBarParent">
          <div :class="$style.balanceBar" />
          <div :class="$style.balanceDetails">
            <div :class="$style.balanceTitle">
              <b :class="$style.spending">Spending</b>
              <div :class="$style.balanceValue">
                <b :class="$style.balanceAmount">
                  <span>$</span>
                  <span :class="$style.span1">3,980</span>
                </b>
              </div>
            </div>
            <div :class="$style.balanceDetailsInner">
              <div :class="$style.parent">
                <b :class="$style.b1">
                  <p :class="$style.p1">+10%</p>
                </b>
                <div :class="$style.ellipseContainer">
                  <div :class="$style.frameChild1" />
                  <img
                    :class="$style.vectorIcon4"
                    loading="lazy"
                    alt=""
                    src="/vector.svg"
                  />
                </div>
              </div>
            </div>
          </div>
          <div :class="$style.frameWrapper">
            <div :class="$style.frameDiv">
              <div :class="$style.frameChild2" />
              <div :class="$style.vectorContainer">
                <img :class="$style.frameChild3" alt="" src="/ellipse-71.svg" />
                <img :class="$style.vectorIcon5" alt="" src="/vector-5.svg" />
              </div>
            </div>
          </div>
          <div :class="$style.frameGroup">
            <div :class="$style.rectangleParent">
              <div :class="$style.frameChild4" />
              <img :class="$style.vectorIcon6" alt="" src="/vector14.svg" />
            </div>
            <div :class="$style.frameContainer">
              <img
                :class="$style.frameIcon"
                loading="lazy"
                alt=""
                src="/frame-14@2x.png"
              />
              <img
                :class="$style.frameChild5"
                loading="lazy"
                alt=""
                src="/frame-15@2x.png"
              />
              <img
                :class="$style.frameChild6"
                loading="lazy"
                alt=""
                src="/frame-15@2x.png"
              />
              <img :class="$style.frameChild7" alt="" src="/frame-17@2x.png" />
              <img :class="$style.polygonIcon" alt="" src="/polygon-2.svg" />
              <img
                :class="$style.rectangleIcon"
                alt=""
                src="/rectangle-65.svg"
              />
            </div>
          </div>
        </div>
        <div :class="$style.balanceUpperBarParent">
          <div :class="$style.balanceUpperBar" />
          <b :class="$style.balance">
            <p :class="$style.balance1">Balance</p>
            <p :class="$style.blankLine">&nbsp;</p>
          </b>
          <div :class="$style.frameParent1">
            <img
              :class="$style.frameChild8"
              loading="lazy"
              alt=""
              src="/frame-22@2x.png"
            />
            <img :class="$style.frameChild9" alt="" src="/frame-22@2x.png" />
            <div :class="$style.frameWrapper1">
              <div :class="$style.ellipseParent1">
                <div :class="$style.frameChild10" />
                <div :class="$style.vectorParent1">
                  <img
                    :class="$style.frameChild11"
                    alt=""
                    src="/ellipse-92.svg"
                  />
                  <img :class="$style.vectorIcon7" alt="" src="/vector13.svg" />
                </div>
              </div>
            </div>
            <img
              :class="$style.frameChild12"
              loading="lazy"
              alt=""
              src="/frame-24@2x.png"
            />
            <div :class="$style.transactionDetails">
              <div :class="$style.transactionContainer">
                <div :class="$style.transactionDetailsContainer">
                  <b :class="$style.transactionValue">
                    <span>$</span>
                    <span :class="$style.span2">2,200</span>
                  </b>
                  <div :class="$style.transactionDetailsContainerInner">
                    <div :class="$style.frameParent2">
                      <div :class="$style.ellipseParent2">
                        <div :class="$style.frameChild13" />
                        <img
                          :class="$style.vectorIcon8"
                          loading="lazy"
                          alt=""
                          src="/vector.svg"
                        />
                      </div>
                      <b :class="$style.transactionPercentage">
                        <p :class="$style.p2">+10%</p>
                      </b>
                    </div>
                  </div>
                </div>
              </div>
              <div :class="$style.rectangleGroup">
                <div :class="$style.frameChild14" />
                <div :class="$style.frameChild15" />
                <div :class="$style.frameChild16" />
                <div :class="$style.frameChild17" />
                <div :class="$style.rectangleContainer">
                  <div :class="$style.frameChild18" />
                  <img :class="$style.vectorIcon9" alt="" src="/vector11.svg" />
                </div>
                <img
                  :class="$style.frameChild19"
                  alt=""
                  src="/ellipse-76.svg"
                />
                <div :class="$style.vectorParent2">
                  <img
                    :class="$style.vectorIcon10"
                    alt=""
                    src="/vector12.svg"
                  />
                  <img
                    :class="$style.frameChild20"
                    alt=""
                    src="/ellipse-77.svg"
                  />
                </div>
                <img
                  :class="$style.containerIcon"
                  alt=""
                  src="/frame-25@2x.png"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div :class="$style.topChartsWrapper">
        <div :class="$style.topCharts">
          <div :class="$style.chartElements">
            <img :class="$style.vectorIcon11" alt="" src="/vector9.svg" />
            <img
              :class="$style.chartElementsChild"
              alt=""
              src="/ellipse-74.svg"
            />
          </div>
          <div :class="$style.chartElements1">
            <img :class="$style.vectorIcon12" alt="" src="/vector10.svg" />
            <img
              :class="$style.chartElementsItem"
              alt=""
              src="/ellipse-75.svg"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script lang="ts">
  import { defineComponent } from "vue";

  export default defineComponent({
    name: "Frame",
  });
</script>
<style module>
  .vectorIcon {
    width: 43px;
    height: 45px;
    position: relative;
  }
  .vectorWrapper {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-57xl) var(--padding-6xl) 0px 0px;
  }
  .frameChild {
    width: 6px;
    height: 65px;
    position: relative;
    border-right: 6px solid var(--color-darkviolet-200);
    box-sizing: border-box;
  }
  .lineWrapper {
    height: 127px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-49xl) var(--padding-9xs) 0px 0px;
    box-sizing: border-box;
  }
  .frameItem {
    height: 147px;
    width: 257px;
    position: relative;
    display: none;
  }
  .income {
    flex: 1;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    z-index: 1;
  }
  .incomeHeader {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px var(--padding-smi) 0px var(--padding-7xs);
  }
  .span {
    color: var(--color-black);
  }
  .b {
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    min-width: 90px;
    white-space: nowrap;
    z-index: 1;
  }
  .incomeHeader1 {
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px var(--padding-11xs);
    font-size: var(--font-size-5xl);
    color: var(--color-gray-300);
  }
  .p {
    margin-block-start: 0;
    margin-block-end: 30px;
  }
  .incomeValue {
    position: absolute;
    top: 0px;
    left: 22px;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    width: 84px;
    height: 33px;
    z-index: 2;
  }
  .frameInner {
    position: absolute;
    top: 0px;
    left: 0px;
    border-radius: 50%;
    background-color: var(--color-whitesmoke-100);
    width: 100%;
    height: 100%;
    z-index: 1;
  }
  .vectorIcon1 {
    position: absolute;
    top: 14px;
    left: 7px;
    width: 11px;
    height: 8px;
    z-index: 2;
  }
  .ellipseParent {
    position: absolute;
    top: 4px;
    left: 0px;
    width: 77px;
    height: 33px;
  }
  .incomeDetails {
    align-self: stretch;
    height: 37px;
    position: relative;
    color: var(--color-limegreen);
  }
  .incomeHeaderParent {
    width: 106px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-7xs);
  }
  .spendingTitlesIcon {
    position: absolute;
    top: 52px;
    left: 20px;
    width: 44px;
    height: 9px;
    object-fit: contain;
    z-index: 1;
  }
  .spendingTitlesIcon1 {
    position: absolute;
    top: 62px;
    left: 20px;
    width: 44px;
    height: 9px;
    object-fit: contain;
    z-index: 1;
  }
  .spendingBar {
    position: absolute;
    top: 2.58px;
    left: 17.69px;
    background-color: var(--color-seagreen);
    border: 1px solid var(--color-darkseagreen);
    box-sizing: border-box;
    width: 23.5px;
    height: 35.7px;
    transform: rotate(-34.9deg);
    transform-origin: 0 0;
  }
  .vectorIcon2 {
    position: absolute;
    top: 14.3px;
    left: 14.2px;
    width: 8.3px;
    height: 11.8px;
    object-fit: contain;
    z-index: 3;
  }
  .spendingBarParent {
    position: absolute;
    top: 8px;
    left: 11.9px;
    width: 34.7px;
    height: 45.7px;
  }
  .ellipseDiv {
    position: absolute;
    top: 0px;
    left: 0px;
    border-radius: 50%;
    background-color: var(--color-khaki-100);
    width: 100%;
    height: 100%;
    z-index: 4;
  }
  .ellipseIcon {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 5;
  }
  .vectorIcon3 {
    position: absolute;
    top: -0.1px;
    left: 3.7px;
    width: 17.4px;
    height: 28.7px;
    object-fit: contain;
    z-index: 6;
  }
  .vectorGroup {
    position: absolute;
    top: 3px;
    left: 1px;
    width: 25px;
    height: 30px;
  }
  .ellipseGroup {
    position: absolute;
    top: 18px;
    left: 0px;
    width: 27px;
    height: 36px;
  }
  .spendingTitlesIcon2 {
    position: absolute;
    top: 42px;
    left: 20px;
    width: 44px;
    height: 9px;
    object-fit: contain;
    z-index: 7;
  }
  .spendingHeaderChild {
    position: absolute;
    top: 34px;
    left: 28px;
    width: 36px;
    height: 8px;
    object-fit: contain;
    z-index: 8;
  }
  .spendingHeaderItem {
    position: absolute;
    top: 5px;
    left: 54px;
    width: 1px;
    height: 26px;
    object-fit: contain;
    z-index: 1;
  }
  .spendingHeaderInner {
    position: absolute;
    top: 0px;
    left: 34px;
    width: 31px;
    height: 12px;
    z-index: 3;
  }
  .rectangleDiv {
    position: absolute;
    top: 9px;
    left: 47px;
    background-color: var(--color-limegreen);
    width: 5px;
    height: 21px;
    z-index: 4;
  }
  .spendingHeader {
    align-self: stretch;
    height: 71px;
    position: relative;
  }
  .spendingHeaderWrapper {
    width: 65px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-8xs) 0px 0px;
    box-sizing: border-box;
  }
  .vectorParent {
    width: 257px;
    background-color: var(--color-lavender);
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-smi) var(--padding-5xs) var(--padding-8xs);
    box-sizing: border-box;
    gap: var(--gap-34xl);
  }
  .balanceBar {
    position: absolute;
    height: 100%;
    top: 0px;
    bottom: 0px;
    left: 0px;
    background-color: var(--color-pink-300);
    width: 263px;
  }
  .spending {
    align-self: stretch;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    z-index: 2;
  }
  .span1 {
    color: var(--color-black);
  }
  .balanceAmount {
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    min-width: 91px;
    white-space: nowrap;
    z-index: 1;
  }
  .balanceValue {
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px var(--padding-11xs);
    margin-top: -4px;
    font-size: var(--font-size-5xl);
    color: var(--color-gray-1000);
  }
  .balanceTitle {
    align-self: stretch;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
  }
  .p1 {
    margin-block-start: 0;
    margin-block-end: 30px;
  }
  .b1 {
    position: absolute;
    top: 0px;
    left: 23px;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    width: 84px;
    height: 33px;
    z-index: 2;
  }
  .frameChild1 {
    position: absolute;
    top: 0px;
    left: 0px;
    border-radius: 50%;
    background-color: var(--color-whitesmoke-200);
    width: 100%;
    height: 100%;
    z-index: 1;
  }
  .vectorIcon4 {
    position: absolute;
    top: 12px;
    left: 5px;
    width: 11px;
    height: 9px;
    z-index: 2;
  }
  .ellipseContainer {
    position: absolute;
    top: 4px;
    left: 0px;
    width: 77px;
    height: 33px;
  }
  .parent {
    height: 37px;
    flex: 1;
    position: relative;
  }
  .balanceDetailsInner {
    width: 123px;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px var(--padding-5xs);
    box-sizing: border-box;
    color: var(--color-limegreen);
  }
  .balanceDetails {
    position: absolute;
    top: 20px;
    left: 7px;
    width: 184px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-2xs);
  }
  .frameChild2 {
    position: absolute;
    top: 0px;
    left: 0px;
    border-radius: 50%;
    background-color: var(--color-khaki-100);
    width: 100%;
    height: 100%;
    z-index: 5;
  }
  .frameChild3 {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 6;
  }
  .vectorIcon5 {
    position: absolute;
    top: -0.1px;
    left: 3.7px;
    width: 17.4px;
    height: 28.7px;
    object-fit: contain;
    z-index: 7;
  }
  .vectorContainer {
    position: absolute;
    top: 3px;
    left: 1px;
    width: 25px;
    height: 30px;
  }
  .frameDiv {
    height: 36px;
    width: 27px;
    position: relative;
  }
  .frameWrapper {
    position: absolute;
    top: 33px;
    left: 191px;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
  }
  .frameChild4 {
    position: absolute;
    top: 2.58px;
    left: 17.69px;
    background-color: var(--color-seagreen);
    border: 1px solid var(--color-darkseagreen);
    box-sizing: border-box;
    width: 23.5px;
    height: 35.7px;
    transform: rotate(-34.9deg);
    transform-origin: 0 0;
    z-index: 3;
  }
  .vectorIcon6 {
    position: absolute;
    top: 14.3px;
    left: 14.2px;
    width: 8.3px;
    height: 11.8px;
    object-fit: contain;
    z-index: 4;
  }
  .rectangleParent {
    position: absolute;
    top: 4px;
    left: 0px;
    width: 34.7px;
    height: 45.7px;
  }
  .frameIcon {
    position: absolute;
    top: 48px;
    left: 0px;
    width: 44px;
    height: 9px;
    object-fit: contain;
    z-index: 1;
  }
  .frameChild5 {
    position: absolute;
    top: 58px;
    left: 0px;
    width: 44px;
    height: 9px;
    object-fit: contain;
    z-index: 1;
  }
  .frameChild6 {
    position: absolute;
    top: 38px;
    left: 0px;
    width: 44px;
    height: 9px;
    object-fit: contain;
    z-index: 8;
  }
  .frameChild7 {
    position: absolute;
    top: 30px;
    left: 8px;
    width: 36px;
    height: 8px;
    object-fit: contain;
    z-index: 9;
  }
  .polygonIcon {
    position: absolute;
    top: 15px;
    left: 14px;
    width: 28px;
    height: 9px;
    object-fit: contain;
    z-index: 5;
  }
  .rectangleIcon {
    position: absolute;
    top: 0px;
    left: 26px;
    width: 4px;
    height: 17px;
    z-index: 6;
  }
  .frameContainer {
    position: absolute;
    top: 0px;
    left: 8.1px;
    width: 44px;
    height: 67px;
  }
  .frameGroup {
    position: absolute;
    top: 19px;
    left: 202.9px;
    width: 52.1px;
    height: 67px;
  }
  .balanceBarParent {
    height: 147px;
    flex: 1;
    position: relative;
    min-width: 176px;
  }
  .balanceUpperBar {
    width: 100%;
    height: 100%;
    position: absolute;
    margin: 0 !important;
    top: 0px;
    right: 0px;
    bottom: 0px;
    left: 0px;
    background-color: var(--color-lightblue);
  }
  .balance1 {
    margin-block-start: 0;
    margin-block-end: 30px;
  }
  .blankLine {
    margin: 0;
  }
  .balance {
    width: 163.1px;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    z-index: 1;
  }
  .frameChild8 {
    height: 7px;
    width: 50px;
    position: absolute;
    margin: 0 !important;
    right: 2px;
    bottom: 41px;
    object-fit: contain;
    z-index: 1;
  }
  .frameChild9 {
    height: 7px;
    width: 50px;
    position: absolute;
    margin: 0 !important;
    right: 2px;
    bottom: 33px;
    object-fit: contain;
    z-index: 1;
  }
  .frameChild10 {
    position: absolute;
    top: 0px;
    left: 0px;
    border-radius: 50%;
    background-color: var(--color-khaki-100);
    width: 100%;
    height: 100%;
    z-index: 10;
  }
  .frameChild11 {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 11;
  }
  .vectorIcon7 {
    position: absolute;
    top: -0.2px;
    left: 4.4px;
    width: 20px;
    height: 23.6px;
    object-fit: contain;
    z-index: 12;
  }
  .vectorParent1 {
    position: absolute;
    top: 3px;
    left: 1px;
    width: 29px;
    height: 25px;
  }
  .ellipseParent1 {
    height: 30px;
    width: 31px;
    position: relative;
  }
  .frameWrapper1 {
    margin: 0 !important;
    position: absolute;
    top: 16px;
    right: 44px;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
  }
  .frameChild12 {
    height: 8px;
    width: 50px;
    position: absolute;
    margin: 0 !important;
    top: 36px;
    right: 2px;
    object-fit: contain;
    z-index: 13;
  }
  .span2 {
    color: var(--color-gray-1200);
  }
  .transactionValue {
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    min-width: 91px;
    white-space: nowrap;
    z-index: 1;
  }
  .frameChild13 {
    position: absolute;
    top: 0px;
    left: 0px;
    border-radius: 50%;
    background-color: var(--color-whitesmoke-200);
    width: 100%;
    height: 100%;
    z-index: 1;
  }
  .vectorIcon8 {
    position: absolute;
    top: 14px;
    left: 8px;
    width: 11px;
    height: 9px;
    z-index: 2;
  }
  .ellipseParent2 {
    position: absolute;
    top: 2px;
    left: 0px;
    width: 77px;
    height: 33px;
  }
  .p2 {
    margin-block-start: 0;
    margin-block-end: 30px;
  }
  .transactionPercentage {
    position: absolute;
    top: 0px;
    left: 26px;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    width: 84px;
    height: 33px;
    z-index: 2;
  }
  .frameParent2 {
    height: 35px;
    flex: 1;
    position: relative;
  }
  .transactionDetailsContainerInner {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px 0px 0px var(--padding-2xs);
    font-size: var(--font-size-base);
    color: var(--color-limegreen);
  }
  .transactionDetailsContainer {
    align-self: stretch;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-11xs);
  }
  .transactionContainer {
    width: 121px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-base) 0px 0px;
    box-sizing: border-box;
  }
  .frameChild14 {
    position: absolute;
    top: 8px;
    left: 13.9px;
    background-color: var(--color-pink-100);
    border: 1px solid var(--color-black);
    box-sizing: border-box;
    width: 39px;
    height: 7px;
    z-index: 2;
  }
  .frameChild15 {
    position: absolute;
    top: 14px;
    left: 14.9px;
    background-color: var(--color-pink-100);
    width: 41px;
    height: 6px;
    z-index: 3;
  }
  .frameChild16 {
    position: absolute;
    top: 20px;
    left: 14.9px;
    background-color: var(--color-pink-100);
    width: 31px;
    height: 7px;
    z-index: 4;
  }
  .frameChild17 {
    position: absolute;
    top: 8.01px;
    left: 51.64px;
    background-color: var(--color-seagreen);
    border: 1px solid var(--color-darkseagreen);
    box-sizing: border-box;
    width: 18.4px;
    height: 31.9px;
    transform: rotate(26.5deg);
    transform-origin: 0 0;
    z-index: 5;
  }
  .frameChild18 {
    position: absolute;
    top: 8.22px;
    left: 0px;
    background-color: var(--color-seagreen);
    border: 1px solid var(--color-darkseagreen);
    box-sizing: border-box;
    width: 18.4px;
    height: 31.9px;
    transform: rotate(-26.5deg);
    transform-origin: 0 0;
  }
  .vectorIcon9 {
    position: absolute;
    top: 13.5px;
    left: 13.1px;
    width: 9.5px;
    height: 9.7px;
    object-fit: contain;
    z-index: 6;
  }
  .rectangleContainer {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 34.2px;
    height: 34.7px;
  }
  .frameChild19 {
    position: absolute;
    top: 11.5px;
    left: 9.6px;
    width: 16px;
    height: 13.4px;
    object-fit: contain;
    z-index: 8;
  }
  .vectorIcon10 {
    position: absolute;
    top: 1.2px;
    left: 2.7px;
    width: 7.3px;
    height: 7.4px;
    object-fit: contain;
    z-index: 7;
  }
  .frameChild20 {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    object-fit: contain;
    z-index: 9;
  }
  .vectorParent2 {
    position: absolute;
    top: 5.9px;
    left: 5.4px;
    width: 12.3px;
    height: 10.2px;
  }
  .containerIcon {
    position: absolute;
    top: 29px;
    left: 28.9px;
    width: 40px;
    height: 7px;
    object-fit: contain;
    z-index: 14;
  }
  .rectangleGroup {
    height: 44.1px;
    width: 70.9px;
    position: relative;
  }
  .transactionDetails {
    flex: 1;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: space-between;
    gap: var(--gap-xl);
  }
  .frameParent1 {
    width: 234px;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    position: relative;
    margin-top: -10px;
    font-size: var(--font-size-5xl);
    color: var(--color-gray-1100);
  }
  .balanceUpperBarParent {
    width: 257px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-lg) var(--padding-5xs) var(--padding-9xs);
    box-sizing: border-box;
    position: relative;
  }
  .frameParent {
    width: 1007px;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    align-items: flex-start;
    justify-content: flex-start;
    gap: var(--gap-17xl);
    max-width: calc(100% - 34px);
  }
  .vectorIcon11 {
    position: absolute;
    top: 1.8px;
    left: 2.4px;
    width: 7.2px;
    height: 8.2px;
    object-fit: contain;
  }
  .chartElementsChild {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    object-fit: contain;
    z-index: 1;
  }
  .chartElements {
    position: absolute;
    top: 5.8px;
    left: 0px;
    width: 11.8px;
    height: 11.4px;
  }
  .vectorIcon12 {
    position: absolute;
    top: 1px;
    left: 1.9px;
    width: 5.5px;
    height: 6.2px;
    object-fit: contain;
  }
  .chartElementsItem {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    object-fit: contain;
    z-index: 2;
  }
  .chartElements1 {
    position: absolute;
    top: 0px;
    left: 4.9px;
    width: 9.1px;
    height: 8.7px;
  }
  .topCharts {
    width: 14px;
    height: 17.2px;
    position: relative;
  }
  .topChartsWrapper {
    height: 74px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
  }
  .chartArea {
    width: 1166.1px;
    display: flex;
    flex-direction: row;
    align-items: flex-end;
    justify-content: space-between;
    gap: var(--gap-xl);
    max-width: 100%;
  }
  .chartAreaWrapper {
    align-self: stretch;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-end;
    max-width: 100%;
    text-align: left;
    font-size: var(--font-size-base);
    color: var(--color-gray-400);
    font-family: var(--font-inter);
  }

  @media screen and (max-width: 750px) {
    .frameParent {
      gap: var(--gap-lg);
    }
  }
  @media screen and (max-width: 450px) {
    .b {
      font-size: var(--font-size-lgi);
      line-height: 32px;
    }

    .balanceAmount {
      font-size: var(--font-size-lgi);
      line-height: 32px;
    }

    .transactionValue {
      font-size: var(--font-size-lgi);
      line-height: 32px;
    }
  }
</style>
