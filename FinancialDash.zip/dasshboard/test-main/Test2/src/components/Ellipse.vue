<template>
  <div :class="$style.dot" />
</template>
<script lang="ts">
  import { defineComponent } from "vue";

  export default defineComponent({
    name: "Ellipse",
  });
</script>
<style module>
  .dot {
    position: absolute;
    height: 100%;
    width: 100%;
    top: 0px;
    right: 0px;
    bottom: 0px;
    left: 0px;
    border-radius: 50%;
    background-color: var(--color-gainsboro-100);
    z-index: 4;
  }
</style>
