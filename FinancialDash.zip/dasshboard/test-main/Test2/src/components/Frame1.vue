<template>
  <div :class="$style.frameParent">
    <div :class="$style.vectorParent">
      <img :class="$style.frameChild" alt="" src="/ellipse-4.svg" />
      <img :class="$style.frameItem" alt="" src="/ellipse-7.svg" />
      <img
        :class="$style.frameInner"
        loading="lazy"
        alt=""
        src="/ellipse-7.svg"
      />
      <img :class="$style.ellipseIcon" alt="" src="/ellipse-4.svg" />
    </div>
    <div :class="$style.overviewContainer">
      <div :class="$style.overviewParent">
        <a :class="$style.overview">
          <p :class="$style.overview1">Overview</p>
          <p :class="$style.blankLine">&nbsp;</p>
        </a>
        <b :class="$style.manageYourFinances"
          >Manage your finances correctly with us</b
        >
      </div>
    </div>
  </div>
</template>
<script lang="ts">
  import { defineComponent } from "vue";

  export default defineComponent({
    name: "Frame1",
  });
</script>
<style module>
  .frameChild {
    position: absolute;
    top: 54px;
    left: 47px;
    width: 69.6px;
    height: 64.5px;
    object-fit: contain;
  }
  .frameItem {
    position: absolute;
    top: 47px;
    left: 0px;
    width: 64.5px;
    height: 69.6px;
    object-fit: contain;
    z-index: 1;
  }
  .frameInner {
    position: absolute;
    top: 0px;
    left: 52px;
    width: 64.5px;
    height: 69.6px;
    object-fit: contain;
    z-index: 2;
  }
  .ellipseIcon {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 69.6px;
    height: 64.5px;
    object-fit: contain;
    z-index: 3;
  }
  .vectorParent {
    height: 118.5px;
    width: 116.6px;
    position: relative;
  }
  .overview1 {
    margin-block-start: 0;
    margin-block-end: 30px;
  }
  .blankLine {
    margin: 0;
  }
  .overview {
    text-decoration: none;
    width: 210px;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    font-weight: 700;
    color: inherit;
    display: inline-block;
  }
  .manageYourFinances {
    align-self: stretch;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    color: var(--color-gray-900);
    z-index: 1;
  }
  .overviewParent {
    align-self: stretch;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
  }
  .overviewContainer {
    width: 860px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: var(--padding-xs) 0px 0px;
    box-sizing: border-box;
    max-width: 100%;
  }
  .frameParent {
    width: 1059px;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: space-between;
    max-width: 100%;
    gap: var(--gap-xl);
    text-align: left;
    font-size: var(--font-size-base);
    color: var(--color-black);
    font-family: var(--font-inter);
  }

  @media screen and (max-width: 1100px) {
    .frameParent {
      flex-wrap: wrap;
    }
  }
</style>
