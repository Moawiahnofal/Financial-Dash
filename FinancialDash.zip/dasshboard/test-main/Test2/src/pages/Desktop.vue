<template>
  <div :class="$style.desktop1">
    <div :class="$style.desktop1Child" />
    <b :class="$style.b">$3,202</b>
    <b :class="$style.children">Children</b>
    <div :class="$style.desktop1Item" />
    <div :class="$style.desktop1Inner" />
    <img :class="$style.vectorIcon" alt="" src="/vector-10.svg" />
    <img :class="$style.desktop1Child1" alt="" src="/vector-9.svg" />
    <section :class="$style.mainContainer">
      <div :class="$style.frameParent"><Frame1 /><frame /></div>
      <div :class="$style.statsContainerWrapper">
        <div :class="$style.statsContainer">
          <div :class="$style.statsHeader">
            <img
              :class="$style.statsIcon"
              loading="lazy"
              alt=""
              src="/vector2.svg"
            />
          </div>
          <h1 :class="$style.statistics">Statistics</h1>
        </div>
      </div>
    </section>
    <div :class="$style.ellipseDiv" />
    <div :class="$style.desktop1Child2" />
    <ChartArea />
  </div>
</template>
<script>
  import { defineComponent } from "vue";
  import Frame1 from "../components/Frame1.vue";
  import Frame from "../components/Frame.vue";
  import ChartArea from "../components/ChartArea.vue";

  export default defineComponent({
    name: "Desktop",
    components: { Frame1, Frame, ChartArea },
  });
</script>
<style module>
  .desktop1Child {
    width: 246px;
    height: 242px;
    position: relative;
    border-radius: 50%;
    background-color: var(--color-powderblue-100);
    display: none;
    z-index: 0;
  }
  .b {
    width: 145px;
    position: relative;
    letter-spacing: -0.01em;
    line-height: 40px;
    display: none;
    white-space: nowrap;
    z-index: 1;
  }
  .children {
    width: 64px;
    position: absolute;
    margin: 0 !important;
    right: -8px;
    bottom: 529px;
    font-size: var(--font-size-xs);
    letter-spacing: -0.01em;
    line-height: 40px;
    display: inline-block;
    color: var(--color-gray-400);
    z-index: 1;
  }
  .desktop1Item {
    width: 1px;
    height: 1px;
    position: relative;
    border-radius: 50%;
    background-color: rgba(28, 18, 18, 0.3);
    display: none;
    z-index: 3;
  }
  .desktop1Inner {
    width: 61px;
    height: 4px;
    position: relative;
    background-color: var(--color-gray-100);
    border: 1px solid var(--color-gainsboro-100);
    box-sizing: border-box;
    display: none;
    z-index: 4;
  }
  .vectorIcon {
    width: 1px;
    height: 0.1px;
    position: relative;
    display: none;
    z-index: 5;
  }
  .desktop1Child1 {
    width: 1px;
    height: 0.1px;
    position: relative;
    display: none;
    z-index: 6;
  }
  .frameParent {
    align-self: stretch;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    gap: 13.5px;
    max-width: 100%;
  }
  .statsIcon {
    width: 43px;
    height: 41px;
    position: relative;
  }
  .statsHeader {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 19px 0px 0px;
  }
  .statistics {
    margin: 0;
    width: 210px;
    position: relative;
    font-size: inherit;
    letter-spacing: -0.01em;
    line-height: 40px;
    font-weight: 700;
    font-family: inherit;
    display: inline-block;
    flex-shrink: 0;
  }
  .statsContainer {
    flex: 1;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: space-between;
    max-width: 100%;
    gap: var(--gap-xl);
  }
  .statsContainerWrapper {
    width: 461px;
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px 49px;
    box-sizing: border-box;
    max-width: 100%;
  }
  .mainContainer {
    width: 1235.1px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 0px var(--padding-xl) 0px 0px;
    box-sizing: border-box;
    gap: var(--gap-13xl);
    max-width: 100%;
    text-align: left;
    font-size: var(--font-size-17xl);
    color: var(--color-black);
    font-family: var(--font-inter);
  }
  .ellipseDiv {
    width: 246px;
    height: 242px;
    position: relative;
    border-radius: 50%;
    background-color: rgba(142, 22, 222, 0.6);
    display: none;
    z-index: 8;
  }
  .desktop1Child2 {
    width: 246px;
    height: 242px;
    position: relative;
    border-radius: 50%;
    background-color: #d8cd56;
    display: none;
    z-index: 9;
  }
  .desktop1 {
    width: 100%;
    position: relative;
    box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
    background-color: var(--color-white);
    overflow: hidden;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    padding: 39px var(--padding-11xs) var(--padding-9xs) 91px;
    box-sizing: border-box;
    gap: var(--gap-31xl);
    line-height: normal;
    letter-spacing: normal;
    text-align: left;
    font-size: 35px;
    color: var(--color-gray-200);
    font-family: var(--font-inter);
  }

  @media screen and (max-width: 1025px) {
    .b {
      font-size: 28px;
      line-height: 32px;
    }

    .statistics {
      font-size: var(--font-size-10xl);
      line-height: 32px;
    }
  }
  @media screen and (max-width: 750px) {
    .mainContainer {
      gap: var(--gap-base);
    }

    .desktop1 {
      gap: var(--gap-6xl);
      padding-left: 45px;
      box-sizing: border-box;
    }
  }
  @media screen and (max-width: 450px) {
    .b {
      font-size: 21px;
      line-height: 24px;
    }

    .statistics {
      font-size: var(--font-size-3xl);
      line-height: 24px;
    }

    .statsContainer {
      flex-wrap: wrap;
    }

    .statsContainerWrapper {
      padding-left: var(--padding-5xl);
      padding-right: var(--padding-5xl);
      box-sizing: border-box;
    }

    .desktop1 {
      padding-left: var(--padding-xl);
      box-sizing: border-box;
    }
  }
</style>
